package com.capgemini.insurance.controller;

import java.io.IOException;
import java.io.PrintWriter;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.capgemini.insurance.dao.AgentClaimCreation;
import com.capgemini.insurance.dao.IAgentClaimCreation;
import com.capgemini.insurance.dto.PolicyDto;


@WebServlet("/agentClaimCreation")
public class AgentClaimCreationServlet extends HttpServlet{
	@Override
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
		
		IAgentClaimCreation agentClaimCreation = new AgentClaimCreation();
		
		try {
			 HttpSession session=request.getSession();  
			String username = (String)session.getAttribute("agentId");
			System.out.println("in agent : "+session.getAttribute("agentId"));
			List<PolicyDto> list = agentClaimCreation.getAllPolicies(username);
			System.out.println("List = " + list);
			request.setAttribute("policy", list);
			
			request.getRequestDispatcher("agentClaimList.jsp").forward(request, response);
			
			
		} catch (Exception e) {
			// TODO Auto-generated catch block
			System.out.println("Error while retrieving the policy details of handler");
		}
		
		//request.setAttribute("policy", list);
		
	}
}
