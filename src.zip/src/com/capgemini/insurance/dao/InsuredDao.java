package com.capgemini.insurance.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;

import com.capgemini.insurance.dto.PolicyDto;
import com.capgemini.insurance.utility.JdbcUtility;

public class InsuredDao implements IInsuredDao {

	Connection connection = null;
	PreparedStatement statement = null;
	ResultSet resultSet = null;
	
	
	@Override
	public ArrayList<PolicyDto> getPolicyData(String username) {
		ArrayList<PolicyDto> policy_list = new ArrayList<PolicyDto>();
		connection = JdbcUtility.getConnection();
		String GET_POLICY_DETAILS = "select policyNumber, policyPremium, accountNumber from policy where accountNumber = (select accountNo from userrole where username = ?)";
		PolicyDto policyDto = null;
		try {
			statement = connection.prepareStatement(GET_POLICY_DETAILS);
			statement.setString(1, username);
			resultSet = statement.executeQuery();
			
			while(resultSet.next()) {
				policyDto = new PolicyDto();
				policyDto.setPolicyNumber(resultSet.getInt(1));
				policyDto.setPolicyPremium(resultSet.getDouble(2));
				policyDto.setAccountNumber(resultSet.getInt(3));
				policy_list.add(policyDto);
			}
			
		} catch (SQLException e) {
			e.printStackTrace();
		}
		return policy_list;
	}
	
	
	@Override
	public String getPolicyName(Integer policyNum) {
		String policyName = null;
		String GET_POLICY_NAME =  "select policyName from policyType where policyNumber = ?";
		try {
			statement = connection.prepareStatement(GET_POLICY_NAME);
			statement.setInt(1, policyNum);
			resultSet = statement.executeQuery();
			while(resultSet.next()) {
				policyName = resultSet.getString(1);
			}
		} catch (SQLException e) {
			e.printStackTrace();
		}
		return policyName;
	}

}
