package com.capgemini.insurance.dao;

import com.capgemini.insurance.dto.UserroleDto;
import com.capgemini.insurance.exception.ClaimRegistrationException;

public interface IAdminDao {
	public String createProfile(UserroleDto userrole) throws ClaimRegistrationException;
}
