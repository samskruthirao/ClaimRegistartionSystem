package com.capgemini.insurance.dao;

public interface QueryConstants {
	final String CREATE_PROFILE = "insert into userrole values(?,?,?)";
	final String GET_POLICY_NUMBER = "select policyNumber from policyType where policyName = ?";
}
