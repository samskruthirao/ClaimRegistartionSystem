package com.cg.dao;

import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;

import com.cg.jdbcutility.JdbcUtility;
import com.cg.service.AgentNameList;


public class AgentNameDAO {

	public List<AgentNameList> list() throws SQLException {
		List<AgentNameList> listName = new ArrayList<>();

		try {
			Connection connection = JdbcUtility.getConnection();

			String sql = "SELECT username from userrole where rolecode='handler'";
			Statement statement = connection.createStatement();
			ResultSet result = statement.executeQuery(sql);

			while (result.next()) {
				String name = result.getString(1);
				AgentNameList agentNameList = new AgentNameList(name);
				listName.add(agentNameList);
			}

		} catch (SQLException ex) {
			ex.printStackTrace();
			throw ex;
		}
		
		
		return listName;
	}
}
