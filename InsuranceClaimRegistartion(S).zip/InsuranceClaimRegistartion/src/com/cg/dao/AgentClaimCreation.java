package com.cg.dao;

import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import com.cg.jdbcutility.JdbcUtility;
import com.cg.service.PolicyDto;

public class AgentClaimCreation implements IAgentClaimCreation {
	
	Connection connection = null;
	PreparedStatement statement = null;
	
	
	@Override
	public List<PolicyDto> getAllPolicies(String user_name) throws Exception {
		connection = JdbcUtility.getConnection();
		List<PolicyDto> listofpolicies = new ArrayList<PolicyDto>();
		
		System.out.println("Usernam = "+user_name);
		try {
			
			String insertQuery = "select p.policyno,p.policypremium,p.accountnum,p.policytype from policydetails1 p,userole1 u where p.accountnum = u.accountno and u.agentname = ?";
			statement = connection.prepareStatement(insertQuery);
			statement.setString(1,user_name);
			ResultSet rs = statement.executeQuery();
			
			
			while(rs.next()) {
				PolicyDto policy = new PolicyDto();
				
				policy.setPolicyNumber(rs.getInt("policyNo"));
				policy.setAccountNumber(rs.getInt("accountNum"));
				policy.setPolicyPremium(rs.getDouble("policyPremium"));
				policy.setPolicyType(rs.getString("policyType"));
				listofpolicies.add(policy);
			
			}
			
		} catch (Exception e) {
			// TODO Auto-generated catch block
			System.out.println(e.getMessage() +"error in agent claim select query");
		}finally {
			connection.close();
		}
		System.out.println("agent Policy details:" + listofpolicies);
		return listofpolicies;
	}

}
