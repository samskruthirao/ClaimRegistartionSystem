package com.capgemini.insurance.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import com.capgemini.insurance.dto.ClaimDto;
import com.capgemini.insurance.exception.ClaimRegistrationException;
import com.capgemini.insurance.utility.JdbcUtility;

public class ClaimCreationDao implements IClaimCreationDao, QueryConstants {
	
	Connection connection = null;
	PreparedStatement statement = null;
	
	@Override
	public boolean createClaim(ClaimDto claimDto) throws ClaimRegistrationException {
		connection = JdbcUtility.getConnection();
		System.out.println("claimDto from create claim: "+claimDto);
		String createClaimQuery = "insert into claim values(claimNumber_sequence.nextval, ? , ?, ?, ?, ?, ?, ?, ?)";
		int rows = 0;
		try {
			statement = connection.prepareStatement(createClaimQuery);
			statement.setString(1, claimDto.getClaimReason());
			statement.setString(2, claimDto.getAccidentStreet());
			statement.setString(3, claimDto.getAccidentCity());
			statement.setString(4, claimDto.getAccidentState());
			statement.setInt(5, claimDto.getAccidentZip());
			statement.setString(6, claimDto.getClaimType());
			statement.setInt(7, claimDto.getPolicyNumber());
			statement.setString(8, claimDto.getUsername());
			rows = statement.executeUpdate();
			System.out.println("Successfully inserted");
			
		} catch (SQLException e) {
			throw new ClaimRegistrationException("Could not enter the claim details");
		}
		if(rows > 0) 
			return true;
		return false;
	}
	
	public int getPolicyNumberUsingClaimType(String claimType) throws ClaimRegistrationException  {
		connection = JdbcUtility.getConnection();
		System.out.println("Claim type is: "+claimType);
		ResultSet resultSet = null;
		
		try {
			statement = connection.prepareStatement(GET_POLICY_NUMBER);
			statement.setString(1, claimType);
			
			resultSet = statement.executeQuery();
			
			int policyNum = 0;
			while(resultSet.next()) {
				System.out.println("In get method ");
				policyNum = resultSet.getInt("policyNumber");
				System.out.println("policy number from method: "+policyNum);
			}
			return policyNum;
		} catch(SQLException e) {
			throw new ClaimRegistrationException("Could not fetch the policy number for the given claim type "+claimType);
		}
		
	}
	
}
