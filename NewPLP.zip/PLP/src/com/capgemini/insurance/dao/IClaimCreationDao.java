package com.capgemini.insurance.dao;

import com.capgemini.insurance.dto.ClaimDto;
import com.capgemini.insurance.exception.ClaimRegistrationException;

public interface IClaimCreationDao {
	public boolean createClaim(ClaimDto claim) throws ClaimRegistrationException;
	public int getPolicyNumberUsingClaimType(String claimType) throws ClaimRegistrationException;
}
