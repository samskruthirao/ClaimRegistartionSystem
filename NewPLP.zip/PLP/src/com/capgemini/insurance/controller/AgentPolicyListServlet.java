package com.capgemini.insurance.controller;

import java.io.IOException;
import java.util.ArrayList;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.capgemini.insurance.dao.AgentDao;
import com.capgemini.insurance.dao.IAgentDao;

import com.capgemini.insurance.dto.PolicyDto;


@WebServlet("/agentPolicyList")
public class AgentPolicyListServlet extends HttpServlet{
	@Override
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		HttpSession session = request.getSession(); 
		String username = (String) session.getAttribute("agentId");
		System.out.println("in policy list servlet: " + username);
		
		IAgentDao agentDao = new AgentDao();
		ArrayList<PolicyDto> policy_list = agentDao.getPolicyData(username);
		ArrayList<String> policyNames_list = new ArrayList<String>(); //insuredDao.getPolicyName(policyNum);
		for(PolicyDto policy: policy_list) {
			policy.setPolicyName(agentDao.getPolicyName(policy.getPolicyNumber()));
			//policyNames_list.add();
		}
		System.out.println("policy_list: " + policy_list);
		System.out.println("policyNames_list: " + policyNames_list);
		
		session.setAttribute("policy_list", policy_list);
		//session.setAttribute("policyNames_list", policyNames_list);
		request.getRequestDispatcher("policyList.jsp").forward(request, response);
		
	}
}
