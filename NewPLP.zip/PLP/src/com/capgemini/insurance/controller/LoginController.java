package com.capgemini.insurance.controller;

import org.apache.log4j.Logger;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.capgemini.insurance.dao.ILoginDAO;
import com.capgemini.insurance.dao.LoginDAOImpl;
import com.capgemini.insurance.dto.UserroleDto;

@WebServlet("/Login")
public class LoginController extends HttpServlet{
	
	Logger logger = Logger.getLogger(LoginController.class);
	
	
	
	@Override
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
		ILoginDAO loginDAO = new LoginDAOImpl();
		RequestDispatcher dispatcher = null;
		
		String username = request.getParameter("username");
		String password = request.getParameter("password");
		System.out.println("username & pwd: "+ username + " " +password);
		UserroleDto user = new UserroleDto(username, password);
		
		logger.info("Username and password entered");
		
		boolean isValidUser = loginDAO.validate(user);
		logger.info("Entered username is "+ username);
		logger.info("Is the username valid? "+ isValidUser);
		//System.out.println(isValidUser);
		String roleCode = loginDAO.getRoleCode(user);
		logger.info("Role code of the user is "+ roleCode);
		//System.out.println(roleCode);
		
	
		if(isValidUser) {
			//System.out.println(roleCode);
			HttpSession session = request.getSession();
			switch (roleCode) {
			case "CLAIM ADJUSTER":
				session.setAttribute("adminId", username);
				session.setAttribute("roleCode",roleCode);
				System.out.println("in login : " + session.getAttribute("adminId"));
				response.sendRedirect("adminPage.jsp");
				logger.info("Control redirected to adminPage.jsp");
				break;
			case "CLAIM HANDLER":
				session.setAttribute("agentId", username);
				session.setAttribute("roleCode",roleCode);
				System.out.println("in login : " + session.getAttribute("agentId"));
				response.sendRedirect("agentPage.jsp");
				logger.info("Control redirected to agentPage.jsp");
				break;
			case "INSURED":
				//System.out.println("I am insured");
				session.setAttribute("insuredId", username);
				session.setAttribute("roleCode",roleCode);
				System.out.println("in login : " + session.getAttribute("insuredId"));
				response.sendRedirect("insuredPage.jsp");
				logger.info("Control redirected to insuredPage.jsp");
				break;
			default:
				break;
			}
			
		}else {
			request.setAttribute("ErrorMsg", "User Name or Password is Invalid!");
			logger.debug("User Name or Password is Invalid!");
			request.getRequestDispatcher("index.jsp").forward(request, response);
		}
	}
}