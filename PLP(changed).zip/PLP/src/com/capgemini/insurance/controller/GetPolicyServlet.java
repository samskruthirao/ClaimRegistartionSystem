package com.capgemini.insurance.controller;

import java.io.IOException;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.capgemini.insurance.dao.IPolicyDao;
import com.capgemini.insurance.dao.PolicyDao;
import com.capgemini.insurance.dto.PolicyDto;

@WebServlet("/getPolicy")
public class GetPolicyServlet extends HttpServlet{
	@Override
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		String policyName = request.getParameter("policyName");
		Integer accNum = Integer.parseInt(request.getParameter("accNum"));
		String status = "no claim request";
		IPolicyDao policyDao = new PolicyDao();
		
		PolicyDto policyDto = policyDao.getPolicyNum_Premium(policyName);
		policyDto.setStatus(status);
		policyDto.setAccountNumber(accNum);
		String message = policyDao.addPolicy(policyDto);
		System.out.println(message);
		
	}
}
