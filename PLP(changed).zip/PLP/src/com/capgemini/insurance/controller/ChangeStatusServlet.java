package com.capgemini.insurance.controller;

import java.io.IOException;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.capgemini.insurance.dao.AdminDao;
import com.capgemini.insurance.dao.IAdminDao;
import com.capgemini.insurance.exception.ClaimRegistrationException;

@WebServlet("/changeStatus")
public class ChangeStatusServlet extends HttpServlet{
	
	@Override
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
		HttpSession session=request.getSession(false);
		IAdminDao changeStatus=new AdminDao();
		String username=request.getParameter("username");
		System.out.println(username);
		int policyNumber=Integer.parseInt(request.getParameter("policyNumber"));
		System.out.println("policy number in change status servlet "+policyNumber);
		String status=request.getParameter("status");
		System.out.println(status);
		if(status.equals("Accepted")) {
			try {
				changeStatus.setStatus(username,policyNumber,status);
			} catch (ClaimRegistrationException e) {
				// TODO Auto-generated catch block
				System.out.println(e.getMessage() +"problem in status update ");
			}
		}
		else if(status.equals("Rejected"))
		{
			try {
				changeStatus.setStatus(username,policyNumber,status);
			} catch (ClaimRegistrationException e) {
				// TODO Auto-generated catch block
				System.out.println(e.getMessage() +"problem in status update ");
			}
		}
		
	}

}
