package com.capgemini.insurance.dao;

import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import com.capgemini.insurance.dto.PolicyDto;
import com.capgemini.insurance.utility.JdbcUtility;


public class AgentClaimCreation implements IAgentClaimCreation {
	
	Connection connection = null;
	PreparedStatement statement = null;
	
	
	@Override
	public List<PolicyDto> getAllPolicies(String user_name) throws Exception {
		connection = JdbcUtility.getConnection();
		List<PolicyDto> listofpolicies = new ArrayList<PolicyDto>();
		
		System.out.println("Username = "+user_name);
		try {
			
			String insertQuery = "select p.policynumber,p.policypremium,p.accountnumber,p.status from policy p,userrole u where p.accountnumber = u.accountno and u.agentname = ?";
			statement = connection.prepareStatement(insertQuery);
			statement.setString(1,user_name);
			ResultSet rs = statement.executeQuery();
			
			
			while(rs.next()) {
				PolicyDto policy = new PolicyDto();
				Integer policyNum = rs.getInt("policyNumber");
				policy.setPolicyNumber(policyNum);
				policy.setAccountNumber(rs.getInt("accountNumber"));
				policy.setPolicyPremium(rs.getDouble("policyPremium"));
				policy.setPolicyName(getPolicyName(policyNum));
				policy.setStatus(rs.getString("status"));
				listofpolicies.add(policy);
			
			}
			
		} catch (Exception e) {
			// TODO Auto-generated catch block
			System.out.println(e.getMessage() +"error in agent claim select query");
		}finally {
			connection.close();
		}
		System.out.println("agent Policy details:" + listofpolicies);
		return listofpolicies;
	}
	
	@Override
	public String getPolicyName(Integer policyNum) {
		Connection connection1 = JdbcUtility.getConnection();
		PreparedStatement preparedStatement = null;
		ResultSet resultSet1 = null;
		String GET_POLICY_NAME = "select policyName from policyType where policyNumber = ?";
		String policyName = null;
		try {
			preparedStatement = connection1.prepareStatement(GET_POLICY_NAME);
			preparedStatement.setInt(1, policyNum);
			resultSet1 = preparedStatement.executeQuery();
			while(resultSet1.next()) {
				policyName = resultSet1.getString(1);
			}
		} catch (SQLException e) {
			e.printStackTrace();
		}
		
		return policyName;
	}

}
