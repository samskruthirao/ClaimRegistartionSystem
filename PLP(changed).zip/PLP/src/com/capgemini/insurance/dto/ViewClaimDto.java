package com.capgemini.insurance.dto;

public class ViewClaimDto {
	
		private Integer claimNumber;
		private String claimType;
		private String claimReason;
		private Integer policyNumber;
		private String status;
		private String username;
		
		

		public ViewClaimDto() {
			super();
		}

		public ViewClaimDto(Integer claimNumber, String claimType, String claimReason, Integer policyNumber,
				String status, String username) {
			super();
			this.claimNumber = claimNumber;
			this.claimType = claimType;
			this.claimReason = claimReason;
			this.policyNumber = policyNumber;
			this.status = status;
			this.username = username;
		}
		
		public Integer getClaimNumber() {
			return claimNumber;
		}
		public void setClaimNumber(Integer claimNumber) {
			this.claimNumber = claimNumber;
		}
		public String getClaimType() {
			return claimType;
		}
		public void setClaimType(String claimType) {
			this.claimType = claimType;
		}
		public String getClaimReason() {
			return claimReason;
		}
		public void setClaimReason(String claimReason) {
			this.claimReason = claimReason;
		}
		public Integer getPolicyNumber() {
			return policyNumber;
		}
		public void setPolicyNumber(Integer policyNumber) {
			this.policyNumber = policyNumber;
		}
		public String getStatus() {
			return status;
		}
		public void setStatus(String status) {
			this.status = status;
		}
		public String getUsername() {
			return username;
		}
		public void setUsername(String username) {
			this.username = username;
		}
		

		
		@Override
		public String toString() {
			return "ViewClaimDto [claimNumber=" + claimNumber + ", claimType=" + claimType + ", claimReason="
					+ claimReason + ", policyNumber=" + policyNumber + ", status=" + status + ", username=" + username
					+ "]";
		}

}
