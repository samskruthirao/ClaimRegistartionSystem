package com.cg.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import javax.servlet.http.HttpSession;

import com.cg.exception.ClaimRegistrationException;
import com.cg.jdbcutility.JdbcUtility;
import com.cg.service.ClaimDto;
import com.cg.service.PolicyDto;

public class AgentClaimDetailsDAO implements IAgentClaimDetailsDAO{
	
	Connection connection = null;
	PreparedStatement statement = null;
	
	@Override
	public Boolean getAllClaimedPolicies(Integer policyNum, ClaimDto claim) throws ClaimRegistrationException, Exception {
		connection = JdbcUtility.getConnection();
		
		Boolean isClaimInserted = false;
		String usernameQuery = "select u.username from userrole u where u.accountno = (select p.accountnum from policydetails p where p.policyno = ?)";
		try {
			statement = connection.prepareStatement(usernameQuery);
		
			statement.setInt(1,policyNum);
			ResultSet rs = statement.executeQuery();
			String clientusername = "";
			while(rs.next()) {
				clientusername = rs.getString(1);
			}
			
			String claimQuery = "select max(claimNumber) from claim";
			statement = connection.prepareStatement(claimQuery);
			rs = statement.executeQuery();
			Integer claimNumber = 0;
			while(rs.next()) {
				claimNumber = rs.getInt(1);
				
			}
			claimNumber++;
			
			String insertQuery = "insert into claim values(?,?,?,?,?,?,?,?,?)";
			statement = connection.prepareStatement(insertQuery);
			statement.setInt(1,claimNumber);
			statement.setString(2,claim.getClaimReason());
			statement.setString(3,claim.getAccidentStreet());
			statement.setString(4,claim.getAccidentCity());
			statement.setString(5,claim.getAccidentState());
			statement.setInt(6,claim.getAccidentZip());
			statement.setString(7,claim.getClaimType());
			statement.setInt(8,policyNum);
			statement.setString(9,clientusername);
			
			
			rs = statement.executeQuery();
			isClaimInserted = rs.next();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			System.out.println("Error while inserting claim details" + e.getMessage());
		} finally {
			connection.close();
		}
		
		return isClaimInserted;
	}

}
