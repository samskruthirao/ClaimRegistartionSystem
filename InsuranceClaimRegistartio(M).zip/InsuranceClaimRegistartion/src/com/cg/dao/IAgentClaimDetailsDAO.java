package com.cg.dao;

import java.util.List;

import com.cg.exception.ClaimRegistrationException;
import com.cg.service.ClaimDto;



public interface IAgentClaimDetailsDAO {
	public Boolean getAllClaimedPolicies(Integer policyNum, ClaimDto claim) throws ClaimRegistrationException, Exception ;
}
