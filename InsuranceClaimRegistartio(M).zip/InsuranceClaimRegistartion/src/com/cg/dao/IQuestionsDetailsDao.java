package com.cg.dao;

import java.util.ArrayList;


import com.cg.exception.ClaimRegistrationException;
import com.cg.service.QuestionsDetailsDto;



public interface IQuestionsDetailsDao {
	public ArrayList<QuestionsDetailsDto> getQuestions(Integer policyNum) throws ClaimRegistrationException;
}
