package com.cg.dao;

import java.util.List;


import com.cg.service.PolicyDto;


public interface IAgentClaimCreation {
	public List<PolicyDto> getAllPolicies(String user_name) throws Exception;
}
