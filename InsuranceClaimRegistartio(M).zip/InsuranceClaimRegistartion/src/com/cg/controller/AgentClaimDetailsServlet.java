package com.cg.controller;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.cg.dao.AgentClaimDetailsDAO;
import com.cg.dao.IAgentClaimDetailsDAO;
import com.cg.service.ClaimDto;

@WebServlet("/agentClaimCreation")
public class AgentClaimDetailsServlet extends HttpServlet{

	@Override
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		IAgentClaimDetailsDAO claimDetailsDAO = new AgentClaimDetailsDAO();
		ClaimDto claim = null;
		Boolean isClaimInserted = false;
		PrintWriter out = null;
		try {
			HttpSession session=request.getSession();  
			Integer policyNum = (Integer) session.getAttribute("Policyno");
			
			String claimReason = request.getParameter("reason");
			String accidentStreet = request.getParameter("street");
			String accidentCity = request.getParameter("city");
			String accidentState = request.getParameter("state");
			Integer accidentZip = Integer.parseInt(request.getParameter("zip"));
			String claimType = request.getParameter("claimType");
			claim = new ClaimDto(claimReason, accidentStreet, accidentCity, accidentState, accidentZip, claimType);
			
			isClaimInserted = claimDetailsDAO.getAllClaimedPolicies(policyNum, claim);

			out.println("Data is successfully inserted");
			request.getRequestDispatcher("getPolicyDetails.jsp").forward(request, response);
			
		}catch (Exception e) {
			// TODO: handle exception

			out.println(e.getMessage() + "The claim details did not get inserted into the database");
			
		}
	}
}
