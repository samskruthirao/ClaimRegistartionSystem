package com.capgemini.insurance.dao;

import java.util.ArrayList;

import com.capgemini.insurance.dto.PolicyDetailsDto;
import com.capgemini.insurance.dto.PolicyDto;

public interface IPolicyDetailsDao {
	public void addPolicyDetails(PolicyDetailsDto policyDetailsDto);
	public ArrayList<PolicyDto> getPolicyDetails(Integer accNum);
	public Integer getAccountNumber(String username);
	public ArrayList<PolicyDto> getPolicyInfo(String username);
	public String getPolicyName(Integer policyNum);
}
