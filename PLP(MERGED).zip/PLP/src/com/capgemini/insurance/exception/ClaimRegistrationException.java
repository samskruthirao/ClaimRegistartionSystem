package com.capgemini.insurance.exception;

public class ClaimRegistrationException extends Exception {
	
	public ClaimRegistrationException(String msg) {
		super(msg);
	}
	
}
