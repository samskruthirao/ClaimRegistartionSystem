package com.cg.dao;



import com.cg.exception.ClaimRegistrationException;
import com.cg.service.UserroleDto;

public interface IAdminDao {
	public String createProfile(UserroleDto userrole) throws ClaimRegistrationException;
}
