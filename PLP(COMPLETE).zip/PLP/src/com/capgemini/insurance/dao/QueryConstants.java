package com.capgemini.insurance.dao;

public interface QueryConstants {
	//ADMIN DAO
	final String INSERT_USERROLE = "insert into userrole values(?,?,?,?,?)";
	final String ALL_CLAIMS = "select * from claim c,policy p where p.policyNumber=c.policyNumber and c.username=(select username from userrole where accountNo=p.accountNumber) and p.status='pending'";
	final String CLAIM_USERNAME = "Select * from claim where username=? and policyNumber=?";
	final String QUESTION_RESPONSE = "select q.question,p.answer from QuestionDetails q,policydetails p where q.QuestionId=p.questionId and p.username=? and q.policyNumber=?";
	final String RESPONSE_CLAIM="select * from claim c,policy p where p.policyNumber=c.policyNumber and c.username=(select username from userrole where accountNo=p.accountNumber) and (p.status='Accepted' or p.status='Rejected')";
	final String GET_STATUS = "update policy set status=? where policyNumber=? and accountNumber=(select accountno from userrole where username=?)";
	
	//AGENT CLAIM CREATION 
	final String GET_POLICY_AGENT = "select p.policynumber,p.policypremium,p.accountnumber,p.status from policy p,userrole u where p.accountnumber = u.accountno and u.agentname = ?";
	final String GET_POLICY_NAME = "select policyName from policyType where policyNumber = ?";
	
	//AGENT DAO
	final String GET_POLICY_DETAILS = "select policyNumber, policyPremium, accountNumber from policy where accountNumber in (select accountNo from userrole where agentname = ?)";
	//String GET_POLICY_NAME =  "select policyName from policyType where policyNumber = ?";
	final String GET_INSURED_NAME =  "select username from userrole where accountNo = ?";
	
	//AGENTNAME DAO
	final String GET_USERNAME = "SELECT username from userrole where rolecode='CLAIM HANDLER'";
	
	//AGENT POLICY DETAILS DAO
	//String GET_POLICY_NAME = "select policyName from policyType where policyNumber = ?";
	final String GET_POLICY_INFO = "select policyNumber, accountNumber, policyPremium, status from policy where accountNumber in (select accountNo from userrole where agentname = ?) and status != 'no claim request'";
	final String ADD_POLICY_DETAILS = "insert into policyDetails values(?, ?, ?, ?)";
	
	//CLAIM CREATION DAO
	final String CREATE_CLAIM = "insert into claim values(claimNumber_sequence.nextval, ? , ?, ?, ?, ?, ?, ?, ?)";
	//String GET_POLICY_NAME =  "select policyName from policyType where policyNumber = ?";
	
	//LOGIN DAO IMPL
	final String USERROLE_DETAILS = "select * from userrole where username=? and password=?";
	final String GET_ROLECODE = "select rolecode from userrole where username=? and password=?";
	
	//POLICY DAO
	final String POLICY_NUM_PREMIUM = "select policyNumber, policyPremium from policyType where policyName = ?";
	final String ADD_POLICY = "insert into policy values(?,?,?,?)";
	
	//POLICY DETAILS DAO
	//String ADD_POLICY_DETAILS = "insert into policyDetails values(?, ?, ?, ?)";
	final String GET_POLICY_DATA = "select * from policy where accountNumber = ?";
	final String GET_ACC_NUM = "select accountNo from userrole where username = ?";
	final String POLICY_INFO_USERNAME = "select policyNumber, accountNumber, policyPremium, status from policy where accountNumber = (select accountNo from userrole where username = ?)";
	//String GET_POLICY_NAME = "select policyName from policyType where policyNumber = ?";
	final String UPDATE_STATUS = "update policy set status = 'pending' where policy.accountNumber = (select accountNo from userrole where username = ?) and policyNumber = ?";
	
	//question details dao
	final String GET_QUESTIONS = "select * from questionDetails where policyNumber = ?";
	final String GET_QUESTION_ID = "select questionId from questionDetails where question = ?";
	
	final String CREATE_PROFILE = "insert into userrole values(?,?,?)";
	final String GET_POLICY_NUMBER = "select policyNumber from policyType where policyName = ?";
	final String POLICY_DETAILS_STATUS = "select policyNumber, policyPremium, accountNumber,status from policy where accountNumber = (select accountNo from userrole where username = ?)";
}
