package com.capgemini.insurance.dto;

public class PolicyTypeDto {
	private Integer policyNumber;
	private String policyName;
	private String policyPremium;
	public PolicyTypeDto() {
		super();
	}
	public PolicyTypeDto(Integer policyNumber, String policyName, String policyPremium) {
		super();
		this.policyNumber = policyNumber;
		this.policyName = policyName;
		this.policyPremium = policyPremium;
	}
	public Integer getPolicyNumber() {
		return policyNumber;
	}
	public void setPolicyNumber(Integer policyNumber) {
		this.policyNumber = policyNumber;
	}
	public String getPolicyName() {
		return policyName;
	}
	public void setPolicyName(String policyName) {
		this.policyName = policyName;
	}
	public String getPolicyPremium() {
		return policyPremium;
	}
	public void setPolicyPremium(String policyPremium) {
		this.policyPremium = policyPremium;
	}
	@Override
	public String toString() {
		return "PolicyTypeDto [policyNumber=" + policyNumber + ", policyName=" + policyName + ", policyPremium="
				+ policyPremium + "]";
	}
	
	
	
	
}
