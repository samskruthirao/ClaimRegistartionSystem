package com.capgemini.insurance.dto;

public class InsuredQuestionResponseDto {
	
	private String Question;
	private String Answer;
	
	public InsuredQuestionResponseDto() {
		super();
		// TODO Auto-generated constructor stub
	}

	public InsuredQuestionResponseDto(String question, String answer) {
		super();
		Question = question;
		Answer = answer;
	}

	public String getQuestion() {
		return Question;
	}

	public void setQuestion(String question) {
		Question = question;
	}

	public String getAnswer() {
		return Answer;
	}

	public void setAnswer(String answer) {
		Answer = answer;
	}

	@Override
	public String toString() {
		return "InsuredQuestionResponseDto [Question=" + Question + ", Answer=" + Answer + "]";
	}
	
	

}
