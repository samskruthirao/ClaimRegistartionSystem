package com.capgemini.insurance.dto;


public class PolicyDetailsDto {
	private Integer policyNumber;
	private String questionId;
	private String answer;
	private String username;
	public PolicyDetailsDto() {
		super();
	}
	public PolicyDetailsDto(Integer policyNumber, String questionId, String answer, String username) {
		super();
		this.policyNumber = policyNumber;
		this.questionId = questionId;
		this.answer = answer;
		this.username = username;
	}
	public Integer getPolicyNumber() {
		return policyNumber;
	}
	public void setPolicyNumber(Integer policyNumber) {
		this.policyNumber = policyNumber;
	}
	public String getQuestionId() {
		return questionId;
	}
	public void setQuestionId(String questionId) {
		this.questionId = questionId;
	}
	public String getAnswer() {
		return answer;
	}
	public void setAnswer(String answer) {
		this.answer = answer;
	}
	public String getUsername() {
		return username;
	}
	public void setUsername(String username) {
		this.username = username;
	}
	@Override
	public String toString() {
		return "PolicyDetailsDto [policyNumber=" + policyNumber + ", questionId=" + questionId + ", answer=" + answer
				+ ", username=" + username + "]";
	}
	
	
	
	
}
