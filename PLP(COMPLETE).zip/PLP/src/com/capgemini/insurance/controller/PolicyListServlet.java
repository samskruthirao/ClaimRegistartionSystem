package com.capgemini.insurance.controller;

import java.io.IOException;
import java.util.ArrayList;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import org.apache.log4j.Logger;
import com.capgemini.insurance.dao.IInsuredDao;
import com.capgemini.insurance.dao.InsuredDao;
import com.capgemini.insurance.dto.PolicyDto;

@WebServlet("/policyList")
public class PolicyListServlet extends HttpServlet {
	
	Logger logger = Logger.getLogger(PolicyListServlet.class);
	
	@Override
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		HttpSession session = request.getSession(false); 
		String username = (String) session.getAttribute("username");
	    
		
		IInsuredDao insuredDao = new InsuredDao();
		ArrayList<PolicyDto> policy_list = insuredDao.getPolicyData(username);
		logger.info("Fetching the policy details of "+ username);
		ArrayList<String> policyNames_list = new ArrayList<String>();
		
		
		for(PolicyDto policy: policy_list) {
			policy.setPolicyName(insuredDao.getPolicyName(policy.getPolicyNumber()));
			
		}
		
		
		session.setAttribute("policy_list", policy_list);
		session.setAttribute("policyNames_list", policyNames_list);
		
		if(session.getAttribute("policyInfo")!=null) {
			
			session.removeAttribute("policyInfo");
			logger.info("Control directed to 'insuredPage.jsp' " );
		}
		
		request.getRequestDispatcher("insuredPage.jsp").forward(request, response);
		
		
	}
	
}
