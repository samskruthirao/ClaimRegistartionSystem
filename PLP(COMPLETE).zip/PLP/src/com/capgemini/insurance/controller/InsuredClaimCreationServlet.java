package com.capgemini.insurance.controller;

import java.io.IOException;
import java.io.PrintWriter;
import java.util.ArrayList;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.capgemini.insurance.dao.ClaimCreationDao;
import com.capgemini.insurance.dao.IClaimCreationDao;
import com.capgemini.insurance.dao.IQuestionsDetailsDao;
import com.capgemini.insurance.dao.QuestionsDetailsDao;
import com.capgemini.insurance.dto.ClaimDto;
import com.capgemini.insurance.dto.QuestionsDetailsDto;
import com.capgemini.insurance.exception.ClaimRegistrationException;

@WebServlet("/ClaimDetails")
public class InsuredClaimCreationServlet extends HttpServlet{
	@Override
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		IClaimCreationDao claimCreationDao = new ClaimCreationDao();
		String claimReason = request.getParameter("reason");
		String accidentStreet = request.getParameter("street");
		String accidentCity = request.getParameter("city");
		String accidentState = request.getParameter("state");
		Integer accidentZip = Integer.parseInt(request.getParameter("zip"));
		String claimType = request.getParameter("details");
		
		HttpSession session = request.getSession(false);
		String username = null;
		
		if(((String)session.getAttribute("roleCode")).equals("CLAIM HANDLER"))
			username=(String) session.getAttribute("insuredName");
		else if(((String)session.getAttribute("roleCode")).equals("INSURED"))
			username=(String) session.getAttribute("username");
		
			//System.out.println("username from claim creation: "+ username);
			
		Integer policyNum = 0;
		try {
			policyNum = claimCreationDao.getPolicyNumberUsingClaimType(claimType);
			//System.out.println("policy number is: "+policyNum);
		} catch (ClaimRegistrationException e1) {
			System.err.println("couldn't fetch the policy number for the given claim type");
		}
		ClaimDto claim = new ClaimDto(claimReason, accidentStreet, accidentCity, accidentState, accidentZip, claimType, policyNum, username);
		System.out.println("complete details: "+claim);
		try {
			claimCreationDao.createClaim(claim);
			PrintWriter out = response.getWriter();
			out.println("<html><body>");
			out.println("<h3>Successfully Inserted Claim Details</h3>");
			out.println("</body></html>");
			session.setAttribute("claimType", claimType);
			session.setAttribute("policyNum", policyNum);
			
			IQuestionsDetailsDao questionDetailsDao = new QuestionsDetailsDao();
			
			ArrayList<QuestionsDetailsDto> questions_list = questionDetailsDao.getQuestions(policyNum);
			System.out.println(questions_list);
			
			session.setAttribute("questions_list", questions_list);
			
			int count = 0;
			for(QuestionsDetailsDto question_dto: questions_list) {
				count++;
				//session.setAttribute("questionId"+count, question.getQuestionId());
				session.setAttribute("questionId"+count, questionDetailsDao.getQuestionsId(question_dto.getQuestion()));
			}
			session.setAttribute("count", count);
			
			request.getRequestDispatcher("getPolicyDetails.jsp").forward(request, response);
			
			
		} catch (ClaimRegistrationException e) {
			e.printStackTrace();
		}

		
		
		
	}
}
