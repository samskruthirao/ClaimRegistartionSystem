package com.cg.controller;

import java.io.IOException;
import java.util.ArrayList;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.cg.dao.IQuestionsDetailsDao;
import com.cg.dao.QuestionsDetailsDao;
import com.cg.exception.ClaimRegistrationException;



@WebServlet("/getPolicyDetails")
public class GetPolicyDetailsServlet extends HttpServlet{
	@Override
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
		
		
		IQuestionsDetailsDao questionDetails = new QuestionsDetailsDao();
		try {
		Integer accNum = Integer.parseInt(request.getParameter("acc_num"));
		String ans1 = request.getParameter("question1");
		String ans2 = request.getParameter("question2");
		String ans3 = request.getParameter("question3");
		String ans4 = request.getParameter("question4");
		String ans5 = request.getParameter("question5");
		//System.out.println("Account number is: "+accNum);
	//	System.out.println(ans1 + " " +ans2 + " " +ans3 + " " +ans4 + " " +ans5 + " ");
		HttpSession session = request.getSession();
		String claimType = (String) session.getAttribute("claimType");
		Integer policyNum = (Integer) session.getAttribute("policyNum");
		//System.out.println(" claimType: "+claimType);
	//	System.out.println(" policyNum: "+policyNum);
		
		} catch(Exception msg) {
			try {
				throw new ClaimRegistrationException("You missed filling field");
			} catch (ClaimRegistrationException e) {
				System.err.println("You missed filling field");
			}
		}
	}
}
