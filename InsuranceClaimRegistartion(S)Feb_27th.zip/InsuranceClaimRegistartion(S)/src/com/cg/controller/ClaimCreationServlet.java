package com.cg.controller;

import java.io.IOException;
import java.util.ArrayList;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.cg.dao.ClaimCreationDao;
import com.cg.dao.IClaimCreationDao;
import com.cg.dao.IQuestionsDetailsDao;
import com.cg.dao.QuestionsDetailsDao;
import com.cg.exception.ClaimRegistrationException;
import com.cg.service.ClaimDto;
import com.cg.service.QuestionsDetailsDto;



@WebServlet("/ClaimDetails")
public class ClaimCreationServlet extends HttpServlet{
	@Override
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		IClaimCreationDao claimCreationDao = new ClaimCreationDao();
		
		
		String claimReason = request.getParameter("reason");
		String accidentStreet = request.getParameter("street");
		String accidentCity = request.getParameter("city");
		String accidentState = request.getParameter("state");
		Integer accidentZip = Integer.parseInt(request.getParameter("zip"));
		String claimType = request.getParameter("details");
		Integer policyNum = 0;
		try {
			HttpSession session=request.getSession();  
			Integer accountNum = (Integer) session.getAttribute("accountNum");
			System.out.println("Calling DAO");
			policyNum = claimCreationDao.getPolicyNumberUsingAccountNumber(accountNum);
			System.out.println("policy number is: "+policyNum);
		} catch (ClaimRegistrationException e1) {
			System.err.println(e1);
			System.out.println("In catch");
		}
		ClaimDto claim = new ClaimDto(claimReason, accidentStreet, accidentCity, accidentState, accidentZip, claimType, policyNum);
		System.out.println("complete details: "+claim);
		try {
			claimCreationDao.createClaim(claim);
			request.setAttribute("claimType", claimType);
			request.setAttribute("policyNum", policyNum);
			
			IQuestionsDetailsDao questionDetails = new QuestionsDetailsDao();
			ArrayList<QuestionsDetailsDto> questions_list = questionDetails.getQuestions(policyNum);
			System.out.println(questions_list);
			
			HttpSession session = request.getSession();
			session.setAttribute("questions_list", questions_list);
			
			request.getRequestDispatcher("getPolicyDetails.jsp").forward(request, response);
			
			//request.getRequestDispatcher("/getPolicyDetails").include(request, response);
		} catch (ClaimRegistrationException e) {
			e.printStackTrace();
		}

		
		
		
	}
}
