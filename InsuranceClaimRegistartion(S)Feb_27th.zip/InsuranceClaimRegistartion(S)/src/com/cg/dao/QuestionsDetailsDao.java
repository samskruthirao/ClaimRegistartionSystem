package com.cg.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;

import com.cg.exception.ClaimRegistrationException;
import com.cg.jdbcutility.JdbcUtility;
import com.cg.service.QuestionsDetailsDto;



public class QuestionsDetailsDao implements IQuestionsDetailsDao {

	Connection connection = null;
	PreparedStatement statement = null;
	ResultSet resultSet = null;
	@Override
	public ArrayList<QuestionsDetailsDto> getQuestions(Integer policyNum) throws ClaimRegistrationException {
		connection = JdbcUtility.getConnection();
		String GET_QUESTIONS = "select * from questionDetails where policyNumber = ?";
		QuestionsDetailsDto questionsDetails = null;
		ArrayList<QuestionsDetailsDto> questionsList = new ArrayList<QuestionsDetailsDto>();
		try {
			statement = connection.prepareStatement(GET_QUESTIONS);
			statement.setInt(1, policyNum);
			resultSet = statement.executeQuery();
			
			while(resultSet.next()) {
				questionsDetails = new QuestionsDetailsDto();
				questionsDetails.setQuestionId(resultSet.getString(1));
				questionsDetails.setPolicyNumber(resultSet.getInt(2));
				questionsDetails.setQuestion(resultSet.getString(3));
				questionsList.add(questionsDetails);
			}
		} catch (SQLException e) {
			throw new ClaimRegistrationException("Couldn't fetch the questions");
		}
		return questionsList;
	}

}
