package com.cg.dao;

public interface QueryConstants {
	final String CREATE_PROFILE = "insert into userole1 values(?,?,?,?,?)";
	final String GET_POLICY_NUMBER = "select policyNo from policydetails1 where accountnum = ?";
}
