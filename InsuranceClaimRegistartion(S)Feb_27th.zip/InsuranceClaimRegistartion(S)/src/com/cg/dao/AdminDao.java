package com.cg.dao;

import com.cg.service.UserroleDto;


import java.sql.Connection;
import java.sql.PreparedStatement;

import com.cg.exception.ClaimRegistrationException;
import com.cg.jdbcutility.*;
public class AdminDao implements IAdminDao{

	Connection connection = null;
	PreparedStatement statement = null;
	
	@Override
	public String createProfile(UserroleDto userrole) throws ClaimRegistrationException {
		
		connection = JdbcUtility.getConnection();
		String query = "insert into userole1 values(?,?,?)";
		int rowsInserted = 0;
		String msg="";
		try {
			statement = connection.prepareStatement(query);
			statement.setString(1, userrole.getUsername());
			statement.setString(2, userrole.getPassword());
			statement.setString(3,userrole.getRolecode());
			rowsInserted = statement.executeUpdate();
			if(rowsInserted > 0) {
				msg = "Successfully inserted";
			} 
		}catch(Exception e) {
			msg = "Couldn't insert the data";
			throw new ClaimRegistrationException(msg);
		}
		return msg;
	}

}
