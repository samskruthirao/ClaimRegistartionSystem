package com.cg.dao;

import com.cg.exception.ClaimRegistrationException;
import com.cg.service.ClaimDto;

public interface IClaimCreationDao {
	public boolean createClaim(ClaimDto claim) throws ClaimRegistrationException;
	public int getPolicyNumberUsingAccountNumber(Integer accountNum) throws ClaimRegistrationException;
}
