package com.cg.exception;

public class ClaimRegistrationException extends Exception {
	
	public ClaimRegistrationException(String msg) {
		super(msg);
	}
	
}
