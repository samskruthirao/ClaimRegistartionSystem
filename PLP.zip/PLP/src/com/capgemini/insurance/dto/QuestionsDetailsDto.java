package com.capgemini.insurance.dto;

public class QuestionsDetailsDto {
	private String questionId;
	private Integer policyNumber;
	private String question;
	public QuestionsDetailsDto() {
		super();
	}
	public QuestionsDetailsDto(String questionId, Integer policyNumber, String question) {
		super();
		this.questionId = questionId;
		this.policyNumber = policyNumber;
		this.question = question;
	}
	public String getQuestionId() {
		return questionId;
	}
	public void setQuestionId(String questionId) {
		this.questionId = questionId;
	}
	public Integer getPolicyNumber() {
		return policyNumber;
	}
	public void setPolicyNumber(Integer policyNumber) {
		this.policyNumber = policyNumber;
	}
	public String getQuestion() {
		return question;
	}
	public void setQuestion(String question) {
		this.question = question;
	}
	@Override
	public String toString() {
		return "QuestionsDetails [questionId=" + questionId + ", policyNumber=" + policyNumber + ", question="
				+ question + "]";
	}
	
	
}
