package com.capgemini.insurance.controller;

import java.io.IOException;
import java.util.ArrayList;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.capgemini.insurance.dao.IPolicyDetailsDao;
import com.capgemini.insurance.dao.PolicyDetailsDao;
import com.capgemini.insurance.dto.PolicyDto;

@WebServlet("/InsuredViewClaim")
public class InsuredViewClaimServlet extends HttpServlet{
	@Override
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		HttpSession session = request.getSession();
		String username =(String) session.getAttribute("username");
		
		IPolicyDetailsDao policyDetailsDao = new PolicyDetailsDao();
		ArrayList<PolicyDto> policyInfo = policyDetailsDao.getPolicyInfo(username);
		System.out.println("policy Info: " +policyInfo);
		session.setAttribute("policyInfo", policyInfo);
		request.getRequestDispatcher("insuredViewClaim.jsp").forward(request, response);
	}
}
