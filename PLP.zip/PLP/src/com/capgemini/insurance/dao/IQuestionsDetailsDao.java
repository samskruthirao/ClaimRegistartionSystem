package com.capgemini.insurance.dao;

import java.util.ArrayList;

import com.capgemini.insurance.dto.QuestionsDetailsDto;
import com.capgemini.insurance.exception.ClaimRegistrationException;

public interface IQuestionsDetailsDao {
	public ArrayList<QuestionsDetailsDto> getQuestions(Integer policyNum) throws ClaimRegistrationException;


	public String getQuestionsId(String question);
}
