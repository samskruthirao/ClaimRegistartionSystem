package com.capgemini.insurance.dao;

import java.util.ArrayList;

import com.capgemini.insurance.dto.PolicyDto;

public interface IInsuredDao {
	public ArrayList<PolicyDto> getPolicyData(String username);
	public String getPolicyName(Integer policyNum);
}
