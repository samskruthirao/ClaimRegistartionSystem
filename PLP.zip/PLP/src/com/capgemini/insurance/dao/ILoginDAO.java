package com.capgemini.insurance.dao;

import com.capgemini.insurance.dto.UserroleDto;

public interface ILoginDAO {

	public boolean validate(UserroleDto user);
	
	public String getRoleCode(UserroleDto user);
}
