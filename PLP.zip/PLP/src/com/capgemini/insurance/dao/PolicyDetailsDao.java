package com.capgemini.insurance.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;

import com.capgemini.insurance.dto.PolicyDetailsDto;
import com.capgemini.insurance.dto.PolicyDto;
import com.capgemini.insurance.utility.JdbcUtility;

public class PolicyDetailsDao implements IPolicyDetailsDao{
	
	Connection connection = null;
	PreparedStatement statement = null;
	ResultSet resultSet = null;
	
	@Override
	public void addPolicyDetails(PolicyDetailsDto policyDetailsDto) {
		connection = JdbcUtility.getConnection();
		Integer policyNum = policyDetailsDto.getPolicyNumber();
		String quesId = policyDetailsDto.getQuestionId();
		String ans = policyDetailsDto.getAnswer();
		String uname = policyDetailsDto.getUsername();
		String addPolicy = "insert into policyDetails values(?, ?, ?, ?)";
		int rows = 0;
		try {
			statement = connection.prepareStatement(addPolicy);
			statement.setInt(1, policyNum);
			statement.setString(2, quesId);
			statement.setString(3, ans);
			statement.setString(4, uname);
			rows = statement.executeUpdate();
		} catch (SQLException e) {
			e.printStackTrace();
		}
		System.out.println("successfully inserted policy details");
	}

	
	@Override
	public ArrayList<PolicyDto> getPolicyDetails(Integer accNum) {
		connection = JdbcUtility.getConnection();
		String GET_POLICY_DETAILS = "select * from policy where accountNumber = ?";
		PolicyDto policyDto = null;
		ArrayList<PolicyDto> policy_list = new ArrayList<PolicyDto>();
		try {
			statement = connection.prepareStatement(GET_POLICY_DETAILS);
			statement.setInt(1, accNum);
			resultSet = statement.executeQuery();
			while(resultSet.next()) {
				policyDto = new PolicyDto();
				policyDto.setPolicyNumber(resultSet.getInt(1));
				policyDto.setPolicyPremium(resultSet.getDouble(2));
				policyDto.setAccountNumber(resultSet.getInt(3));
				policyDto.setStatus(resultSet.getString(4));
				policy_list.add(policyDto);
			}
		} catch (SQLException e) {
			e.printStackTrace();
		}
		
		return policy_list;
	}


	@Override
	public Integer getAccountNumber(String username) {
		connection = JdbcUtility.getConnection();
		String GET_ACC_NUM = "select accountNo from userrole where username = ?";
		Integer accNum = 0;
		
		try {
			
			statement = connection.prepareStatement(GET_ACC_NUM);
			statement.setString(1, username);
			resultSet = statement.executeQuery();
			while(resultSet.next()) {
				accNum = resultSet.getInt(1);
			}
			
		} catch (SQLException e) {
			e.printStackTrace();
		}
		return accNum;
	}

	
	@Override
	public ArrayList<PolicyDto> getPolicyInfo(String username) {
		connection = JdbcUtility.getConnection();
		System.out.println("username: " + username);
		String GET_POLICY_INFO = "select policyNumber, accountNumber, policyPremium, status from policy where accountNumber = (select accountNo from userrole where username = ?)";
		ArrayList<PolicyDto> policyInfo_list = new ArrayList<PolicyDto>();
		PolicyDto policyDto;
		try {
			statement = connection.prepareStatement(GET_POLICY_INFO);
			statement.setString(1, username);
			resultSet = statement.executeQuery();
			int i=0;
			while(resultSet.next()) {
				i++;
				policyDto = new PolicyDto();
				Integer policyNum = resultSet.getInt(1);
				policyDto.setPolicyNumber(policyNum);
				policyDto.setAccountNumber(resultSet.getInt(2));
				policyDto.setPolicyPremium(resultSet.getDouble(3));
				policyDto.setStatus(resultSet.getString(4));
				policyDto.setPolicyName(getPolicyName(policyNum));
				System.out.println(policyDto);
				policyInfo_list.add(policyDto);
			}
			System.out.println("count "+i);
		} catch (SQLException e) {
			e.printStackTrace();
		}
		return policyInfo_list;
	}


	@Override
	public String getPolicyName(Integer policyNum) {
		Connection connection1 = JdbcUtility.getConnection();
		PreparedStatement preparedStatement = null;
		ResultSet resultSet1 = null;
		String GET_POLICY_NAME = "select policyName from policyType where policyNumber = ?";
		String policyName = null;
		try {
			preparedStatement = connection1.prepareStatement(GET_POLICY_NAME);
			preparedStatement.setInt(1, policyNum);
			resultSet1 = preparedStatement.executeQuery();
			while(resultSet1.next()) {
				policyName = resultSet1.getString(1);
			}
		} catch (SQLException e) {
			e.printStackTrace();
		}
		
		return policyName;
	}
	
	
}
