package com.capgemini.insurance.dao;

import com.capgemini.insurance.dto.PolicyDto;

public interface IPolicyDao {
	public PolicyDto getPolicyNum_Premium(String policyName);
	public String addPolicy(PolicyDto policyDto);
}
