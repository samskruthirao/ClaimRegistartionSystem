package com.capgemini.insurance.dao;

import java.util.ArrayList;

import com.capgemini.insurance.dto.PolicyDetailsDto;
import com.capgemini.insurance.dto.PolicyDto;

public interface IAgentPolicyDetailsDao {
	public ArrayList<PolicyDto> getPolicyInfoOfClients(String agentName);

	String getPolicyName(Integer policyNum);

	void addPolicyDetails(PolicyDetailsDto policyDetailsDto);
}
