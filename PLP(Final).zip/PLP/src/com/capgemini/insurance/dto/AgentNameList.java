package com.capgemini.insurance.dto;

public class AgentNameList {
	
	String agentName;

	public AgentNameList(String agentName) {
		super();
		this.agentName = agentName;
	}

	public String getAgentName() {
		return agentName;
	}

	public void setAgentName(String agentName) {
		this.agentName = agentName;
	}

	@Override
	public String toString() {
		return "AgentNameList [agentName=" + agentName + "]";
	}
	
	

}
