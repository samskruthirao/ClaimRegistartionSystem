package com.capgemini.insurance.controller;

import java.io.IOException;
import org.apache.log4j.Logger;
import java.util.ArrayList;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.capgemini.insurance.dao.AgentPolicyDetailsDao;
import com.capgemini.insurance.dao.IAgentPolicyDetailsDao;
import com.capgemini.insurance.dto.PolicyDto;

@WebServlet("/agentViewClaim")
public class AgentViewClaimServlet extends HttpServlet {
	Logger logger = Logger.getLogger(AgentViewClaimServlet.class);
	
	@Override
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		HttpSession session = request.getSession(false);
		String username =(String) session.getAttribute("username");
		
		IAgentPolicyDetailsDao policyDetailsDao = new AgentPolicyDetailsDao();
		ArrayList<PolicyDto> policyInfo = policyDetailsDao.getPolicyInfoOfClients(username);

		logger.info("Fetched Policy details of " + username);
		session.setAttribute("policyInfo", policyInfo);
		
		if(session.getAttribute("policy")!=null) {
			session.removeAttribute("policy");
			logger.info("Control directed to 'agentPage.jsp' ");
		}
		
		request.getRequestDispatcher("agentPage.jsp").forward(request, response);
		
	}
}
