package com.capgemini.insurance.controller;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import org.apache.log4j.Logger;
/**
 * Servlet implementation class LogoutServlet
 */
@WebServlet("/LogoutServlet")
public class LogoutServlet extends HttpServlet {
	
	Logger logger = Logger.getLogger(LogoutServlet.class);
	
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {

		HttpSession session=request.getSession();
		
		if(session.getAttribute("roleCode").equals("CLAIM HANDLER"))
			session.removeAttribute("username");
		else if(session.getAttribute("roleCode").equals("CLAIM ADJUSTER"))
			session.removeAttribute("username");
		else
			session.removeAttribute("username");
		
		session.invalidate();
		response.sendRedirect("index.jsp");
		PrintWriter out = response.getWriter();
		out.println("<html><body>");
		out.println("<h3>Logged out!!Successfully </h3>");
		out.println("</body></html>");
		logger.info("Logged out successfully");
		
	}

}
