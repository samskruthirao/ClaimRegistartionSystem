/*To change the status of claim*/

package com.capgemini.insurance.controller;

import java.io.IOException;
import org.apache.log4j.Logger;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.capgemini.insurance.dao.AdminDao;
import com.capgemini.insurance.dao.IAdminDao;
import com.capgemini.insurance.exception.ClaimRegistrationException;

@WebServlet("/changeStatus")
public class ChangeStatusServlet extends HttpServlet {

	Logger logger = Logger.getLogger(ChangeStatusServlet.class);

	@Override
	protected void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {

		HttpSession session = request.getSession(false);
		
		IAdminDao changeStatus = new AdminDao();
		
		String username = request.getParameter("username");
		int policyNumber = Integer.parseInt(request.getParameter("policyNumber"));
		String status = request.getParameter("status");
		
		if (status.equals("Accepted")) {
			try {
				changeStatus.setStatus(username, policyNumber, status);
				logger.info("Status Updated");
			} catch (ClaimRegistrationException e) {
				logger.error("Can't update Status");
			}
		} else if (status.equals("Rejected")) {
			try {
				changeStatus.setStatus(username, policyNumber, status);
				logger.info("Status Updated");
			} catch (ClaimRegistrationException e) {
				logger.error("Can't update Status");
			}
		}
	}
}
