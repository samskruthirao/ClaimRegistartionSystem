package com.capgemini.insurance.dao;

import java.util.List;

import com.capgemini.insurance.dto.ClaimDto;
import com.capgemini.insurance.dto.InsuredQuestionResponseDto;
import com.capgemini.insurance.dto.UserroleDto;
import com.capgemini.insurance.dto.ViewClaimDto;
import com.capgemini.insurance.exception.ClaimRegistrationException;

public interface IAdminDao {
	
	public String createProfile(UserroleDto userrole) throws ClaimRegistrationException;
	
	public List<ViewClaimDto> getAllClaim() throws ClaimRegistrationException;
	
	public List<ClaimDto> getClaimDetails(String username,Integer policyNumber) throws ClaimRegistrationException;
	
	public List<InsuredQuestionResponseDto> getQuestionResponse(String username,Integer policyNumber) throws ClaimRegistrationException;
	
	public List<ViewClaimDto> getResponseClaimDetails() throws ClaimRegistrationException;
	
	public void setStatus(String username,Integer policyNumber,String status) throws ClaimRegistrationException;
}
