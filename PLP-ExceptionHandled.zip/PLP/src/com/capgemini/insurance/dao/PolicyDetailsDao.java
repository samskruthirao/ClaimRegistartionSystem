package com.capgemini.insurance.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import org.apache.log4j.Logger;
import com.capgemini.insurance.dto.PolicyDetailsDto;
import com.capgemini.insurance.dto.PolicyDto;
import com.capgemini.insurance.utility.JdbcUtility;

public class PolicyDetailsDao implements IPolicyDetailsDao, QueryConstants{
	Logger logger = Logger.getLogger(PolicyDetailsDao.class);
	Connection connection = null;
	PreparedStatement statement = null;
	ResultSet resultSet = null;
	
	@Override
	public void addPolicyDetails(PolicyDetailsDto policyDetailsDto) {
		connection = JdbcUtility.getConnection();
		Integer policyNum = policyDetailsDto.getPolicyNumber();
		String quesId = policyDetailsDto.getQuestionId();
		String ans = policyDetailsDto.getAnswer();
		String uname = policyDetailsDto.getUsername();
		
		int rows = 0;
		try {
			statement = connection.prepareStatement(ADD_POLICY);
			statement.setInt(1, policyNum);
			statement.setString(2, quesId);
			statement.setString(3, ans);
			statement.setString(4, uname);
			rows = statement.executeUpdate();
		} catch (SQLException e) {
			logger.error("Connection to database failed", e);
		}
		
		logger.info("Inserted policy details successfuly");
	}

	
	@Override
	public ArrayList<PolicyDto> getPolicyDetails(Integer accNum) {
		connection = JdbcUtility.getConnection();
		PolicyDto policyDto = null;
		ArrayList<PolicyDto> policy_list = new ArrayList<PolicyDto>();
		try {
			statement = connection.prepareStatement(GET_POLICY_DATA);
			statement.setInt(1, accNum);
			resultSet = statement.executeQuery();
			while(resultSet.next()) {
				policyDto = new PolicyDto();
				policyDto.setPolicyNumber(resultSet.getInt(1));
				policyDto.setPolicyPremium(resultSet.getDouble(2));
				policyDto.setAccountNumber(resultSet.getInt(3));
				policyDto.setStatus(resultSet.getString(4));
				policy_list.add(policyDto);
			}
		} catch (SQLException e) {
			logger.error("Connection to database failed", e);
		}
		
		logger.info("Policy Details are shown");
		return policy_list;
		
	}


	@Override
	public Integer getAccountNumber(String username) {
		connection = JdbcUtility.getConnection();
		Integer accNum = 0;
		
		try {
			
			statement = connection.prepareStatement(GET_ACC_NUM);
			statement.setString(1, username);
			resultSet = statement.executeQuery();
			while(resultSet.next()) {
				accNum = resultSet.getInt(1);
			}
			
		} catch (SQLException e) {
			logger.error("Connection to database failed", e);
		}
		
		logger.info("Account Number is retrieved ");
		return accNum;
	}

	
	@Override
	public ArrayList<PolicyDto> getPolicyInfo(String username) {
		connection = JdbcUtility.getConnection();
	
		ArrayList<PolicyDto> policyInfo_list = new ArrayList<PolicyDto>();
		PolicyDto policyDto;
		try {
			statement = connection.prepareStatement(POLICY_INFO_USERNAME);
			statement.setString(1, username);
			resultSet = statement.executeQuery();
			while(resultSet.next()) {
				policyDto = new PolicyDto();
				Integer policyNum = resultSet.getInt(1);
				policyDto.setPolicyNumber(policyNum);
				policyDto.setAccountNumber(resultSet.getInt(2));
				policyDto.setPolicyPremium(resultSet.getDouble(3));
				policyDto.setStatus(resultSet.getString(4));
				policyDto.setPolicyName(getPolicyName(policyNum));
				
				policyInfo_list.add(policyDto);
			}
		} catch (SQLException e) {
			logger.error("Connection to database failed", e);
			
		}
		logger.info("Policy Details are retrieved");
		return policyInfo_list;
	}


	@Override
	public String getPolicyName(Integer policyNum) {
		Connection connection1 = JdbcUtility.getConnection();
		PreparedStatement preparedStatement = null;
		ResultSet resultSet1 = null;
		String policyName = null;
		try {
			preparedStatement = connection1.prepareStatement(GET_POLICY_NAME);
			preparedStatement.setInt(1, policyNum);
			resultSet1 = preparedStatement.executeQuery();
			while(resultSet1.next()) {
				policyName = resultSet1.getString(1);
			}
		} catch (SQLException e) {
			logger.error("Connection to database failed", e);
		}
		
		logger.info("Policy name is retrieved");
		return policyName;
	}


	@Override
	public void updateStatus(String username, Integer policyNum) {
		connection = JdbcUtility.getConnection();
		
		try {
			statement = connection.prepareStatement(UPDATE_STATUS);
			statement.setString(1, username);
			statement.setInt(2, policyNum);
			statement.executeUpdate();
		
			logger.info("Status updated successfully");
		} catch (SQLException e) {
			logger.error("Connection to database failed", e);
		}
		
		
	}
	
	
}
