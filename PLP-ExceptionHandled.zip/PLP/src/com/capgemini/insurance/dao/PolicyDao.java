package com.capgemini.insurance.dao;

import java.sql.*;

import com.capgemini.insurance.dto.PolicyDto;
import com.capgemini.insurance.utility.JdbcUtility;

public class PolicyDao implements IPolicyDao, QueryConstants {
	Connection connection = null;
	PreparedStatement statement = null;
	ResultSet resultSet = null;
	
	
	@Override
	public PolicyDto getPolicyNum_Premium(String policyName) {
		System.out.println("policy name is: "+policyName);
		connection = JdbcUtility.getConnection();
		PolicyDto policyDto = new PolicyDto();
		try {
			statement = connection.prepareStatement(POLICY_NUM_PREMIUM);
			statement.setString(1, policyName);
			resultSet = statement.executeQuery();
			while(resultSet.next()) {
				policyDto.setPolicyNumber(resultSet.getInt(1));
				policyDto.setPolicyPremium(resultSet.getDouble(2));
				policyDto.setPolicyName(policyName);
			}
			
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return policyDto;
	}
	
	
	
	@Override
	public String addPolicy(PolicyDto policyDto) {
		connection = JdbcUtility.getConnection();
		String ADD_POLICY = "insert into policy values(?,?,?,?)";
		 
		int row = 0;
		try {
			statement = connection.prepareStatement(ADD_POLICY);
			statement.setInt(1, policyDto.getPolicyNumber());
			statement.setDouble(2, policyDto.getPolicyPremium());
			statement.setInt(3, policyDto.getAccountNumber());
			statement.setString(4, policyDto.getStatus());
			row = statement.executeUpdate();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		if(row > 0)
			return "Successfully inserted the policy details";
		return "Failed to insert the policy details";
	}

}
