package com.capgemini.insurance.testing;

import static net.sourceforge.jwebunit.junit.JWebUnit.*;

import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Test;

import com.capgemini.insurance.dto.AccountDto;

import net.sourceforge.jwebunit.util.TestingEngineRegistry;

public class testingApplication {
	private AccountDto  number1, number2;
}
	@BeforeClass
    public static void prepare() {
        setTestingEngineKey(TestingEngineRegistry.TESTING_ENGINE_HTMLUNIT); 
        setBaseUrl("http://localhost:8089/InsuranceProject");
    }
	@Before
	public void setUp() throws Exception {
	      System.out.println("Run @Before"); // for illustration
	      number1 = new MyNumber(11);
	      number2 = new MyNumber(22);
 
    @Test
    public void testIndexPage() {
        beginAt("index.jsp"); 
        assertTitleEquals("InsuranceAdda.com");
        assertFormPresent("login");
        
        
    }
    
    public void testGetterSetter() {
        System.out.println("Run @Test testGetterSetter"); // for illustration
        int value = 33;
        number1.setNumber(value);
        assertEquals("error in getter/setter", value, number1.getNumber());
     }
    
    @Test
    public void testHomePage() {
        beginAt("home.jsp"); 
        assertTitleEquals("Home Page");
        assertLinkPresent("index");
        clickLink("index");
        assertTitleEquals("Index page");
    }
    
}



