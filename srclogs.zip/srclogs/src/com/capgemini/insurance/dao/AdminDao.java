package com.capgemini.insurance.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;

import com.capgemini.insurance.dto.UserroleDto;
import com.capgemini.insurance.exception.ClaimRegistrationException;
import com.capgemini.insurance.utility.JdbcUtility;

public class AdminDao implements IAdminDao, QueryConstants{

	Connection connection = null;
	PreparedStatement statement = null;
	
	@Override
	public String createProfile(UserroleDto userrole) throws ClaimRegistrationException {
		
		connection = JdbcUtility.getConnection();
		int rowsInserted = 0;
		String msg="";
		try {
			statement = connection.prepareStatement(CREATE_PROFILE);
			statement.setString(1, userrole.getUsername());
			statement.setString(2, userrole.getPassword());
			statement.setString(3,userrole.getRolecode());
			rowsInserted = statement.executeUpdate();
			if(rowsInserted > 0) {
				msg = "Successfully inserted";
			} 
		}catch(Exception e) {
			msg = "Couldn't insert the data";
			throw new ClaimRegistrationException(msg);
		}
		return msg;
	}

}
