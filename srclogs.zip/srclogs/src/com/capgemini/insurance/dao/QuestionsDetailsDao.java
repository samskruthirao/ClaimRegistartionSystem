package com.capgemini.insurance.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;

import com.capgemini.insurance.dto.QuestionsDetailsDto;
import com.capgemini.insurance.exception.ClaimRegistrationException;
import com.capgemini.insurance.utility.JdbcUtility;

public class QuestionsDetailsDao implements IQuestionsDetailsDao {

	Connection connection = null;
	PreparedStatement statement = null;
	ResultSet resultSet = null;
	@Override
	public ArrayList<QuestionsDetailsDto> getQuestions(Integer policyNum) throws ClaimRegistrationException {
		connection = JdbcUtility.getConnection();
		String GET_QUESTIONS = "select * from questionDetails where policyNumber = ?";
		QuestionsDetailsDto questionsDetails = null;
		ArrayList<QuestionsDetailsDto> questionsList = new ArrayList<QuestionsDetailsDto>();
		try {
			statement = connection.prepareStatement(GET_QUESTIONS);
			statement.setInt(1, policyNum);
			resultSet = statement.executeQuery();
			
			while(resultSet.next()) {
				questionsDetails = new QuestionsDetailsDto();
				questionsDetails.setQuestionId(resultSet.getString(1));
				questionsDetails.setPolicyNumber(resultSet.getInt(2));
				questionsDetails.setQuestion(resultSet.getString(3));
				questionsList.add(questionsDetails);
			}
		} catch (SQLException e) {
			throw new ClaimRegistrationException("Couldn't fetch the questions");
		}
		return questionsList;
	}
	
	
	@Override
	public String getQuestionsId(String question) {
		connection = JdbcUtility.getConnection();
		String GET_QUESTION_ID = "select questionId from questionDetails where question = ?";
		String questionId = null;
		try {
			statement = connection.prepareStatement(GET_QUESTION_ID);
			statement.setString(1, question);
			resultSet = statement.executeQuery();
			while(resultSet.next()) {
				questionId = resultSet.getString(1);
			}
		} catch (SQLException e) {
			e.printStackTrace();
		}
		return questionId;
	}

}
