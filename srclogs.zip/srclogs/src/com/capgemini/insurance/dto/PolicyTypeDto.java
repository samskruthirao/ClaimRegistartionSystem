package com.capgemini.insurance.dto;

public class PolicyTypeDto {
	private Integer policyNumber;
	private String policyName;
	public PolicyTypeDto() {
		super();
	}
	public PolicyTypeDto(Integer policyNumber, String policyName) {
		super();
		this.policyNumber = policyNumber;
		this.policyName = policyName;
	}
	public Integer getPolicyNumber() {
		return policyNumber;
	}
	public void setPolicyNumber(Integer policyNumber) {
		this.policyNumber = policyNumber;
	}
	public String getPolicyName() {
		return policyName;
	}
	public void setPolicyName(String policyName) {
		this.policyName = policyName;
	}
	@Override
	public String toString() {
		return "PolicyType [policyNumber=" + policyNumber + ", policyName=" + policyName + "]";
	}
	
	
}
