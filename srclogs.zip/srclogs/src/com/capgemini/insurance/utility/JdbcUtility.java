package com.capgemini.insurance.utility;

import java.sql.Connection;
import java.sql.Driver;
import java.sql.DriverManager;
import java.sql.SQLException;

import com.capgemini.insurance.exception.ClaimRegistrationException;

import oracle.jdbc.driver.OracleDriver;

public class JdbcUtility  {
	/*public static Connection connection = null;
	
	public static Connection getConnection() throws Exception {
		Driver driver = new OracleDriver();
		
		try {
			DriverManager.registerDriver(driver);
			connection = DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521:XE", "system", "root");
		} catch (SQLException e) {
			String msg = "Problem occured while connecting to the database";
			throw new ClaimRegistrationException(msg);
		}
		return connection;
		
	}*/
	
	public static Connection getConnection() {

		Connection con = null;
		String driver = "oracle.jdbc.OracleDriver";
		String url = "jdbc:oracle:thin:@localhost:1521:XE";
		String username = "system";
		String password = "root";

		try {
			Class.forName(driver);
		} catch (Exception e) {
			e.printStackTrace();
		}

		try {
			con = DriverManager.getConnection(url, username, password);
		} catch (Exception e) {
			e.printStackTrace();
		}
		return con;
	}
}
