package com.capgemini.insurance.dto;

import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.util.ArrayList;

import com.capgemini.insurance.dto.ClaimDto;
import com.capgemini.insurance.dto.InsuredQuestionResponseDto;
import com.itextpdf.text.Anchor;
import com.itextpdf.text.BaseColor;
import com.itextpdf.text.Document;
import com.itextpdf.text.DocumentException;
import com.itextpdf.text.PageSize;
import com.itextpdf.text.Paragraph;
import com.itextpdf.text.Rectangle;
import com.itextpdf.text.pdf.PdfPCell;
import com.itextpdf.text.pdf.PdfPTable;
import com.itextpdf.text.pdf.PdfWriter;

public class PDFCreate{
	
	
	public int create(ArrayList<ClaimDto> claimDetails, ArrayList<InsuredQuestionResponseDto> responseDetails) {
		
		Rectangle pageSize = new Rectangle(595,842);
		pageSize.setBackgroundColor(new BaseColor(245, 203, 162));
		Document doc = new Document(pageSize,50,50,50,50);
		
		try {
			System.out.println("Inside pdf create.java " + claimDetails.get(0).getClaimNumber());
			PdfWriter writer = PdfWriter.getInstance(doc, new FileOutputStream(
					"D:\\" + claimDetails.get(0).getUsername() + "_" + claimDetails.get(0).getClaimNumber() + ".pdf"));
			doc.open();
			
			
			
			Anchor at = new Anchor("SafeHands.com");
			
			Paragraph para1 = new Paragraph();
			para1.setSpacingBefore(50);
			para1.add(at);
			doc.add(para1);

			PdfPTable table = new PdfPTable(2);
			table.setSpacingBefore(50);
			table.setSpacingAfter(50);
			table.getDefaultCell().setBackgroundColor(new BaseColor(242, 182, 128));
			
			PdfPCell pdfPCell1 = new PdfPCell(new Paragraph("Policy Details"));
			pdfPCell1.setBackgroundColor(new BaseColor(240, 168, 105));
			pdfPCell1.setBorder(Rectangle.NO_BORDER);
			pdfPCell1.setColspan(2);
			table.addCell(pdfPCell1);
			
			table.addCell("Claim Number");
			table.addCell("" + claimDetails.get(0).getClaimNumber());

			table.addCell("Claim Type");
			table.addCell("" + claimDetails.get(0).getClaimType());

			table.addCell("Claim Reason");
			table.addCell("" + claimDetails.get(0).getClaimReason());

			table.addCell("Policy Number");
			table.addCell("" + claimDetails.get(0).getPolicyNumber());

			table.addCell("Username");
			table.addCell("" + claimDetails.get(0).getUsername());

			table.addCell("Accident Street");
			table.addCell("" + claimDetails.get(0).getAccidentStreet());

			table.addCell("Accident City");
			table.addCell("" + claimDetails.get(0).getAccidentCity());

			table.addCell("Accident State");
			table.addCell("" + claimDetails.get(0).getAccidentState());

			table.addCell("ZIP Code");
			table.addCell("" + claimDetails.get(0).getAccidentZip());
			
			
			for (InsuredQuestionResponseDto responseDetail : responseDetails) {
				table.addCell("" + responseDetail.getQuestion());
				table.addCell("" + responseDetail.getAnswer());
			}

			doc.add(table);

			doc.close();

			return 1;
		} catch (FileNotFoundException e) {
			System.out.println(e.getMessage());
		} catch (DocumentException e) {
			System.out.println(e.getMessage());
		}
		return 0;
	}
}
