/*Servlet to create a policy for the insured*/
package com.capgemini.insurance.controller;

import java.io.IOException;
import java.io.PrintWriter;

import org.apache.log4j.Logger;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.capgemini.insurance.dao.IPolicyDao;
import com.capgemini.insurance.dao.PolicyDao;
import com.capgemini.insurance.dto.PolicyDto;

@WebServlet("/getPolicy")
public class GetPolicyServlet extends HttpServlet{
	Logger logger = Logger.getLogger(GetPolicyServlet.class);

	@Override
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		String policyName = request.getParameter("policyName");
		Integer accNum = Integer.parseInt(request.getParameter("accNum"));
		String status = "no claim request";
		IPolicyDao policyDao = new PolicyDao();
		PolicyDto policyDto = policyDao.getPolicyNum_Premium(policyName);
		policyDto.setStatus(status);
		policyDto.setAccountNumber(accNum);
		
		/*Creating a policy for the given account number*/
		String message = policyDao.addPolicy(policyDto);
		PrintWriter out = response.getWriter();
		
	
		request.setAttribute("policyMsg",message);
		logger.info("Policy details are successfully inserted ");
		request.getRequestDispatcher("getPolicy.jsp").forward(request, response);
		
	}
}
