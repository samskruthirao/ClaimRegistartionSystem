package com.capgemini.insurance.controller;

import java.io.IOException;
import java.io.PrintWriter;
import java.util.ArrayList;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;


import com.capgemini.insurance.dto.ClaimDto;
import com.capgemini.insurance.dto.InsuredQuestionResponseDto;
import com.capgemini.insurance.dto.PDFCreate;
@WebServlet("/generateReport")
public class GenerateReportServlet  extends HttpServlet{
	@Override
	protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
		PrintWriter out=resp.getWriter();
		HttpSession session=req.getSession(false);
		
		ArrayList<ClaimDto> claimDetails = (ArrayList<ClaimDto>) session.getAttribute("claimDetailsList");
		ArrayList<InsuredQuestionResponseDto> responseDetails = (ArrayList<InsuredQuestionResponseDto>) session.getAttribute("questionResponseList");
		
		PDFCreate pdf=new PDFCreate();
		int pdfConfirm=pdf.create(claimDetails, responseDetails);
		if(pdfConfirm==0)
		{
			out.println("pdf not generated");
		}
		else {
			out.println("pdf is generated,Find report in D Drive");
		}
		
		
		
	}

}
