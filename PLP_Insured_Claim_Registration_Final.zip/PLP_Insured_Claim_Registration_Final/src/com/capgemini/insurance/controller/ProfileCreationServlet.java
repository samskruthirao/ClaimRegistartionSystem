/*Servlet for profile creation of all the 3 roles */

package com.capgemini.insurance.controller;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.capgemini.insurance.dao.AdminDao;
import com.capgemini.insurance.dao.IAdminDao;
import com.capgemini.insurance.dto.UserroleDto;
import com.capgemini.insurance.exception.ClaimRegistrationException;
import org.apache.log4j.Logger;

@WebServlet("/profileCreation")
public class ProfileCreationServlet extends HttpServlet {
	Logger logger = Logger.getLogger(ProfileCreationServlet.class);

	@Override
	protected void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		System.out.println("in profile creation");
		String userName = request.getParameter("uname");
		String password = request.getParameter("pwd");
		String role = request.getParameter("insRoles");
		String agentName = "";
		Long accountNum1 = Long.parseLong(request.getParameter("account"));
		if (role.equals("INSURED")) {
			agentName = request.getParameter("agentName1");

		}
		if (role.equals("CLAIM ADJUSTER") || role.equals("CLAIM HANDLER")) {
			agentName = "";
		}
		UserroleDto userroleDto = new UserroleDto(userName, password, role, accountNum1, agentName);
		IAdminDao adminDao = new AdminDao();
		PrintWriter out = response.getWriter();
		try {
			/*Adding the userroles details which were entered by the admin */
			String msg = adminDao.createProfile(userroleDto);

			logger.info("Profile for " + userName + " successfully created");
			request.setAttribute("profileCreate", msg);
			request.getRequestDispatcher("createProfile.jsp").forward(request, response);
		} catch (ClaimRegistrationException e) {
			logger.error("Failed to create profile ");

		}

	}
}
