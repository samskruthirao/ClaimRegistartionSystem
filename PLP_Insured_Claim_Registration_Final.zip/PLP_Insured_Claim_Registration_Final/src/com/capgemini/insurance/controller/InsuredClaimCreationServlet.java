/*Servlet to retrieve the claim details entered by the Insured  from getClaimDetails.jsp
*/

package com.capgemini.insurance.controller;

import java.io.IOException;
import java.io.PrintWriter;
import java.util.ArrayList;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.capgemini.insurance.dao.ClaimCreationDao;
import com.capgemini.insurance.dao.IClaimCreationDao;
import com.capgemini.insurance.dao.IQuestionsDetailsDao;
import com.capgemini.insurance.dao.QuestionsDetailsDao;
import com.capgemini.insurance.dto.ClaimDto;
import com.capgemini.insurance.dto.QuestionsDetailsDto;
import com.capgemini.insurance.exception.ClaimRegistrationException;

@WebServlet("/ClaimDetails")
public class InsuredClaimCreationServlet extends HttpServlet{
	@Override
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		IClaimCreationDao claimCreationDao = new ClaimCreationDao();
		String claimReason = request.getParameter("reason");
		String accidentStreet = request.getParameter("street");
		String accidentCity = request.getParameter("city");
		String accidentState = request.getParameter("state");
		Integer accidentZip = Integer.parseInt(request.getParameter("zip"));
		String claimType = request.getParameter("details");
		
		HttpSession session = request.getSession(false);
		String username = null;
		
		if(((String)session.getAttribute("roleCode")).equals("CLAIM HANDLER"))
			username=(String) session.getAttribute("insuredName");
		else if(((String)session.getAttribute("roleCode")).equals("INSURED"))
			username=(String) session.getAttribute("username");
		
		Integer policyNum = 0;
		try {
			policyNum = claimCreationDao.getPolicyNumberUsingClaimType(claimType);
			
		} catch (ClaimRegistrationException e1) {
			System.err.println("couldn't fetch the policy number for the given claim type");
		}
		ClaimDto claim = new ClaimDto(claimReason, accidentStreet, accidentCity, accidentState, accidentZip, claimType, policyNum, username);
	
		try {
			claimCreationDao.createClaim(claim);
			PrintWriter out = response.getWriter();

			session.setAttribute("claimType", claimType);
			session.setAttribute("policyNum", policyNum);
			
			IQuestionsDetailsDao questionDetailsDao = new QuestionsDetailsDao();
			
			/*Fetching the questions for given policy number*/
			ArrayList<QuestionsDetailsDto> questions_list = questionDetailsDao.getQuestions(policyNum);
			
			
			session.setAttribute("questions_list", questions_list);
			
			int count = 0;
			for(QuestionsDetailsDto question_dto: questions_list) {
				count++;
				session.setAttribute("questionId"+count, questionDetailsDao.getQuestionsId(question_dto.getQuestion()));
			}
			session.setAttribute("count", count);
			
			/*Redirecting the control to the getPolicyDetails.jsp page*/
			request.getRequestDispatcher("getPolicyDetails.jsp").forward(request, response);
			
			
		} catch (ClaimRegistrationException e) {
			System.err.println("error while fetching questions list");
		}

		
		
		
	}
}
