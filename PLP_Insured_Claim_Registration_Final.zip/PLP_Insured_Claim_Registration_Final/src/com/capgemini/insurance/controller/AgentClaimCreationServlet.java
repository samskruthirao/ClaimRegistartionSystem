/*Servlet to fetch the claim and policy details of the insured*/
package com.capgemini.insurance.controller;

import java.io.IOException;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.capgemini.insurance.dao.AgentClaimCreation;
import com.capgemini.insurance.dao.IAgentClaimCreation;
import com.capgemini.insurance.dto.PolicyDto;
import org.apache.log4j.Logger;

@WebServlet("/agentClaimCreation")
public class AgentClaimCreationServlet extends HttpServlet {

	Logger logger = Logger.getLogger(AgentClaimCreationServlet.class);

	@Override
	protected void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {

		IAgentClaimCreation agentClaimCreation = new AgentClaimCreation();

		try {
			HttpSession session = request.getSession(false);

			String username = (String) session.getAttribute("username");
			List<PolicyDto> list = agentClaimCreation.getAllPolicies(username);

			if (list.isEmpty()) {
				logger.debug("Empty list is returned " + list);
			}

			request.setAttribute("policy", list);

			if (session.getAttribute("policyInfo") != null) {
				session.removeAttribute("policyInfo");
				logger.info("Control redirected to 'agentPage.jsp' ");
			}

			request.getRequestDispatcher("agentPage.jsp").forward(request, response);

		} catch (Exception e) {
			logger.error("Error while retrieving the policy details of handler", e);
		}

	}
}
