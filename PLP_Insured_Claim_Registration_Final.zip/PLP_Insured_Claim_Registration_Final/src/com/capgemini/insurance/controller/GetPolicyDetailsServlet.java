/*Servlet to get all the policy choices opted by the Insured for policy questions*/

package com.capgemini.insurance.controller;

import java.io.IOException;
import java.io.PrintWriter;
import java.util.ArrayList;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.capgemini.insurance.dao.ILoginDAO;
import com.capgemini.insurance.dao.IPolicyDetailsDao;
import com.capgemini.insurance.dao.IQuestionsDetailsDao;
import com.capgemini.insurance.dao.LoginDAOImpl;
import com.capgemini.insurance.dao.PolicyDetailsDao;
import com.capgemini.insurance.dao.QuestionsDetailsDao;
import com.capgemini.insurance.dto.PolicyDetailsDto;
import com.capgemini.insurance.dto.QuestionsDetailsDto;
import com.capgemini.insurance.exception.ClaimRegistrationException;

@WebServlet("/getPolicyDetails")
public class GetPolicyDetailsServlet extends HttpServlet{
	@Override
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
		
		
		IQuestionsDetailsDao questionDetails = new QuestionsDetailsDao();
		try {
	//	Integer accNum = Integer.parseInt(request.getParameter("acc_num"));
		String ans1 = request.getParameter("question1");
		String ans2 = request.getParameter("question2");
		String ans3 = request.getParameter("question3");
		String ans4 = request.getParameter("question4");
		String ans5 = request.getParameter("question5");
		String ans[] = {ans1, ans2, ans3, ans4, ans5};
		System.out.println("In get policy details servlet");
		System.out.println(ans1 + " " +ans2 + " " +ans3 + " " +ans4 + " " +ans5 + " ");
		HttpSession session = request.getSession(false);
		String claimType = (String) session.getAttribute("claimType");
		Integer policyNum = (Integer) session.getAttribute("policyNum");
		
		String roleCode=(String)session.getAttribute("roleCode");
		String username = null;
		
		if(roleCode.equals("CLAIM HANDLER"))
			username=(String) session.getAttribute("insuredName");
		else if(roleCode.equals("INSURED"))
			username=(String) session.getAttribute("username");
		
			System.out.println("username from claim creation: "+ username);
			
		IPolicyDetailsDao policyDetailsDao = new PolicyDetailsDao();
		PolicyDetailsDto policyDetailsDto = null;
		int count = (int) session.getAttribute("count");

		PrintWriter out = response.getWriter();
		for(int i = 1; i <= count; i++) {
			String quest = (String) session.getAttribute("questionId"+ i);
			policyDetailsDto = new PolicyDetailsDto(policyNum, quest, ans[i-1], username);
			System.out.println(policyDetailsDto);
			
			/*Adding the policy details opted by the Insured*/
			policyDetailsDao.addPolicyDetails(policyDetailsDto);
		
		}
		request.setAttribute("QuesDetails", "Claim created Successfully!Please check the status");
		policyDetailsDao.updateStatus(username, policyNum);
	    if(roleCode.equals("INSURED"))
	    	request.getRequestDispatcher("insuredPage.jsp").forward(request, response);
	    else 
	    	request.getRequestDispatcher("agentPage.jsp").forward(request, response);
		} catch(Exception msg) {
			try {
				throw new ClaimRegistrationException("You missed filling field");
			} catch (ClaimRegistrationException e) {
				System.err.println("You missed filling field");
			}
		}
	}
}
