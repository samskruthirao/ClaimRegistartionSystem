package com.capgemini.insurance.dao;

import java.util.ArrayList;

import com.capgemini.insurance.dto.PolicyDto;

public interface IAgentDao {

	ArrayList<PolicyDto> getPolicyData(String username);

	String getPolicyName(Integer policyNum);
	
	String getInsuredName(long accountNumber);

}
