package com.capgemini.insurance.dao;

import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;

import com.capgemini.insurance.dto.AgentNameList;
import com.capgemini.insurance.utility.JdbcUtility;


public class AgentNameDAO implements QueryConstants{

	
	public List<AgentNameList> list() throws SQLException {
		List<AgentNameList> listName = new ArrayList<>();

		try {
			Connection connection = JdbcUtility.getConnection();

			Statement statement = connection.createStatement();
			ResultSet result = statement.executeQuery(GET_USERNAME);

			while (result.next()) {
				String name = result.getString(1);
				AgentNameList agentNameList = new AgentNameList(name);
				listName.add(agentNameList);
			}

		} catch (SQLException ex) {
			ex.printStackTrace();
			throw ex;
		}
		
		
		return listName;
	}
}
