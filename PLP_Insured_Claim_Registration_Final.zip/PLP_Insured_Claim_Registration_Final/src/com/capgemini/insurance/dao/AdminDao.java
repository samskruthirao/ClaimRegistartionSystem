package com.capgemini.insurance.dao;




import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;

import com.capgemini.insurance.dto.ClaimDto;
import com.capgemini.insurance.dto.InsuredQuestionResponseDto;
import com.capgemini.insurance.dto.UserroleDto;
import com.capgemini.insurance.dto.ViewClaimDto;
import com.capgemini.insurance.exception.ClaimRegistrationException;
import com.capgemini.insurance.utility.JdbcUtility;


public class AdminDao implements IAdminDao, QueryConstants{

	Connection connection = null;
	PreparedStatement statement = null;
	
	/*Method to create the profile of the Insured, Claim Handler and Claim Adjuster*/
	
	@Override
	public String createProfile(UserroleDto userrole) throws ClaimRegistrationException {
		
		connection = JdbcUtility.getConnection();
		
		int rowsInserted = 0;
		String msg="";
		try {
			statement = connection.prepareStatement(INSERT_USERROLE);
			statement.setString(1, userrole.getUsername());
			statement.setString(2, userrole.getPassword());
			statement.setString(3,userrole.getRolecode());
			statement.setLong(4, userrole.getAccountNumber());
			statement.setString(5,userrole.getAgentName());
			rowsInserted = statement.executeUpdate();
			if(rowsInserted > 0) {
				msg = "Profile created Successfully";
			}
		}catch(Exception e) {
			msg = "User already exists";
			return msg;
		}
		finally {
			try {
				connection.close();
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				System.out.println(e.getMessage() +"problem in connection ");
			}
		}
		return msg;
	}

	/*Method to get the claim details of the claims created */
	@Override
	public List<ViewClaimDto> getAllClaim() throws ClaimRegistrationException {
		// TODO Auto-generated method stub
		ViewClaimDto viewClaimDto=null;
		List<ViewClaimDto> listOfClaims=new ArrayList<ViewClaimDto>();
		Statement statement=null;
		ResultSet resultSet=null;
		connection=JdbcUtility.getConnection();
		
		try {
		statement=connection.createStatement();
		
		statement.executeQuery(ALL_CLAIMS);
		
		resultSet=statement.getResultSet();
		
		while(resultSet.next())
		{
			
			viewClaimDto=new ViewClaimDto();
			viewClaimDto.setClaimNumber(resultSet.getInt(1));
			viewClaimDto.setClaimType(resultSet.getString(7));
			viewClaimDto.setClaimReason(resultSet.getString(2));
			viewClaimDto.setPolicyNumber(resultSet.getInt(8));
			viewClaimDto.setStatus(resultSet.getString(13));
			viewClaimDto.setUsername(resultSet.getString(9));
			listOfClaims.add(viewClaimDto);
		}
		} catch (Exception e) {
		// TODO Auto-generated catch block
		System.out.println(e.getMessage() +"error in fetching  claim details");
	}finally {
		try {
			connection.close();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			System.out.println(e.getMessage() +"problem in connection ");
		}
	}
	System.out.println("agent Policy details:" + listOfClaims);
	
	return listOfClaims;
	
	}

	
	/*Method to get the claim details for particular policy of an Insured*/
	
	@Override
	public List<ClaimDto> getClaimDetails(String username, Integer policyNumber) throws ClaimRegistrationException {
		// TODO Auto-generated method stub
		ResultSet resultSet=null;
		ClaimDto claimDetails=null;
		List<ClaimDto> insuredClaimDetails=new ArrayList<ClaimDto>();
		
		connection=JdbcUtility.getConnection();
		
		try {
			statement=connection.prepareStatement(CLAIM_USERNAME);
			statement.setString(1,username);
			statement.setInt(2,policyNumber);
			statement.executeQuery();
			resultSet = statement.getResultSet();
			
			while(resultSet.next())
			{
				claimDetails=new ClaimDto();
				claimDetails.setClaimNumber(resultSet.getInt(1));
				claimDetails.setClaimType(resultSet.getString(7));
				claimDetails.setClaimReason(resultSet.getString(2));
				claimDetails.setAccidentStreet(resultSet.getString(3));
				claimDetails.setAccidentCity(resultSet.getString(4));
				claimDetails.setAccidentState(resultSet.getString(5));
				claimDetails.setAccidentZip(resultSet.getInt(6));
				claimDetails.setPolicyNumber(resultSet.getInt(8));
				claimDetails.setUsername(resultSet.getString(9));
				insuredClaimDetails.add(claimDetails);
			}
		} catch (SQLException e) {
			System.out.println(e.getMessage() +"error in fetching  claim details");
		}finally {
			try {
				connection.close();
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				System.out.println(e.getMessage() +"problem in connection ");
			}
		}
		System.out.println("insured Claim details:" + insuredClaimDetails);
		
		return insuredClaimDetails;
	}
	
	
	/*Method to get the choices opted by the Insured for the questions*/
	@Override
	public List<InsuredQuestionResponseDto> getQuestionResponse(String username, Integer policyNumber)
			throws ClaimRegistrationException {
		// TODO Auto-generated method stub
		ResultSet resultSet=null;
		ClaimDto claimDetails=null;
		List<InsuredQuestionResponseDto> insuredQuestionResponse=new ArrayList<InsuredQuestionResponseDto>();
		try {
		connection=JdbcUtility.getConnection();
		
		statement=connection.prepareStatement(QUESTION_RESPONSE);
		statement.setString(1,username);
		statement.setInt(2,policyNumber);
		statement.executeQuery();
		resultSet = statement.getResultSet();
		
		while(resultSet.next())
		{
			InsuredQuestionResponseDto questionResponse=new InsuredQuestionResponseDto();
			questionResponse.setQuestion(resultSet.getString(1));
			questionResponse.setAnswer(resultSet.getString(2));
			insuredQuestionResponse.add(questionResponse);
		}
		
		}
		catch (SQLException e) {
			System.out.println(e.getMessage() +"error in fetching  insured question Response");
		}finally {
			try {
				connection.close();
			} catch (SQLException e) {
				System.out.println(e.getMessage() +"problem in connection ");
			}
		}
		System.out.println("insured question Response:" + insuredQuestionResponse);
	
		
		return insuredQuestionResponse;
	}

	/*Method to get all the claim details */
	@Override
	public List<ViewClaimDto> getResponseClaimDetails()
			throws ClaimRegistrationException {
		
		ViewClaimDto viewClaimDto=null;
		List<ViewClaimDto> listOfClaims=new ArrayList<ViewClaimDto>();
		Statement statement=null;
		ResultSet resultSet=null;
		connection=JdbcUtility.getConnection();
		
		try {
		statement=connection.createStatement();
		
		statement.executeQuery(RESPONSE_CLAIM);
		
		resultSet=statement.getResultSet();
		
		while(resultSet.next())
		{
			
			viewClaimDto=new ViewClaimDto();
			viewClaimDto.setClaimNumber(resultSet.getInt(1));
			viewClaimDto.setClaimType(resultSet.getString(7));
			viewClaimDto.setClaimReason(resultSet.getString(2));
			viewClaimDto.setPolicyNumber(resultSet.getInt(8));
			viewClaimDto.setStatus(resultSet.getString(13));
			viewClaimDto.setUsername(resultSet.getString(9));
			listOfClaims.add(viewClaimDto);
		}
		} catch (Exception e) {
		// TODO Auto-generated catch block
		System.out.println(e.getMessage() +"error in fetching  claim details");
	}finally {
		try {
			connection.close();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			System.out.println(e.getMessage() +"problem in connection ");
		}
	}
	System.out.println("agent Policy details:" + listOfClaims);
	
	return listOfClaims;
	}

		/*Method to update the status after the claim creation*/
	@Override
	public void setStatus(String username, Integer policyNumber, String status)  throws ClaimRegistrationException{
		// TODO Auto-generated method stub
		
		connection = JdbcUtility.getConnection();
		
		int rowsInserted = 0;
		String msg="";
		try {
			statement = connection.prepareStatement(GET_STATUS);
			statement.setString(1, status);
			statement.setInt(2, policyNumber);
			statement.setString(3,username);
			rowsInserted = statement.executeUpdate();
			if(rowsInserted > 0) {
				msg = "Successfully inserted";
			} 
		}catch(Exception e) {
			msg = "Couldn't insert the data";
			throw new ClaimRegistrationException(msg);
		}
		finally {
			try {
				connection.close();
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				System.out.println(e.getMessage() +"problem in connection ");
			}
		}
	}

	
	
}
