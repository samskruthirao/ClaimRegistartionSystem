package com.capgemini.insurance.dao;

import java.util.List;

import com.capgemini.insurance.dto.PolicyDto;


public interface IAgentClaimCreation {
	public List<PolicyDto> getAllPolicies(String user_name) throws Exception;

	String getPolicyName(Integer policyNum);
}
