package com.capgemini.insurance.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import com.capgemini.insurance.dto.UserroleDto;
import com.capgemini.insurance.exception.ClaimRegistrationException;
import com.capgemini.insurance.utility.JdbcUtility;


public class LoginDAOImpl implements ILoginDAO, QueryConstants {

	PreparedStatement statement = null;
	ResultSet resultSet = null;
	
	/*Method to validate the credentials of the user to verify whether the user is authorized or not*/
	@Override
	public boolean validate(UserroleDto user) {
		Connection con = JdbcUtility.getConnection();

		boolean validateFlag = false;
		try {
			statement = con.prepareStatement(USERROLE_DETAILS);
			statement.setString(1, user.getUsername());
			statement.setString(2, user.getPassword());

			resultSet = statement.executeQuery();
			System.out.println("hai "+ resultSet.getRow());
			validateFlag = resultSet.next();
		} catch (SQLException e) {
			e.printStackTrace();
		} finally {
			try {
				statement.close();
			} catch (SQLException e2) {
				e2.printStackTrace();
			}

			try {
				con.close();
			} catch (SQLException e2) {
				e2.printStackTrace();
			}
		}
		
		return validateFlag;
	}

	/*Method to get the rolecode based on the username */
	@Override
	public String getRoleCode(UserroleDto user){
		
		String roleCode = null;
		Connection con = JdbcUtility.getConnection();
		try {
			statement = con.prepareStatement(GET_ROLECODE);
			statement.setString(1, user.getUsername());
			statement.setString(2, user.getPassword());

			resultSet = statement.executeQuery();
			while(resultSet.next()) {
			roleCode = resultSet.getString("rolecode");
			}
			
		} catch (SQLException e) {
			e.printStackTrace();
		} finally {
			try {
				statement.close();
			} catch (SQLException e2) {
				e2.printStackTrace();
			}

			try {
				con.close();
			} catch (SQLException e2) {
				e2.printStackTrace();
			}
		}
		return roleCode;
	}
	
}
