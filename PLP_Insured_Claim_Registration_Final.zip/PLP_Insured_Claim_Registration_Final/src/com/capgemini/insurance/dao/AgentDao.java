package com.capgemini.insurance.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;

import com.capgemini.insurance.dto.PolicyDto;
import com.capgemini.insurance.utility.JdbcUtility;

public class AgentDao implements  IAgentDao, QueryConstants{
	Connection connection = null;
	PreparedStatement statement = null;
	ResultSet resultSet = null;
	
	/*Method to get the policy details of the given username*/
	@Override
	public ArrayList<PolicyDto> getPolicyData(String username) {
		ArrayList<PolicyDto> policy_list = new ArrayList<PolicyDto>();
		connection = JdbcUtility.getConnection();
		PolicyDto policyDto = null;
		try {
			statement = connection.prepareStatement(GET_POLICY_DETAILS);
			statement.setString(1, username);
			resultSet = statement.executeQuery();
			
			while(resultSet.next()) {
				policyDto = new PolicyDto();
				policyDto.setPolicyNumber(resultSet.getInt(1));
				policyDto.setPolicyPremium(resultSet.getDouble(2));
				policyDto.setAccountNumber(resultSet.getInt(3));
				policy_list.add(policyDto);
			}
			
		} catch (SQLException e) {
			e.printStackTrace();
		}
		return policy_list;
	}
	
	
	/*Method to get the policy name for the given policy number*/
	@Override
	public String getPolicyName(Integer policyNum) {
		connection = JdbcUtility.getConnection();
		String policyName = null;
		try {
			statement = connection.prepareStatement(GET_POLICY_NAME);
			statement.setInt(1, policyNum);
			resultSet = statement.executeQuery();
			while(resultSet.next()) {
				policyName = resultSet.getString(1);
			}
		} catch (SQLException e) {
			e.printStackTrace();
		}
		return policyName;
	}

	/*Method to get the insured username based on the given account number*/
	@Override
	public String getInsuredName(long accountNumber) {
		connection = JdbcUtility.getConnection();
		String insuredName = null;
		try {
			statement = connection.prepareStatement(GET_INSURED_NAME);
			statement.setLong(1, accountNumber);
			resultSet = statement.executeQuery();
			while(resultSet.next()) {
				insuredName = resultSet.getString(1);
			}
		} catch (SQLException e) {
			e.printStackTrace();
		}
		System.out.println(insuredName);
		return insuredName;
	}
}
