package com.capgemini.insurance.dao;

import java.sql.Connection;
import org.apache.log4j.Logger;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;

import com.capgemini.insurance.dto.PolicyDto;
import com.capgemini.insurance.utility.JdbcUtility;

public class InsuredDao implements IInsuredDao, QueryConstants {

	
	Logger logger = Logger.getLogger(InsuredDao.class);
	Connection connection = null;
	PreparedStatement statement = null;
	ResultSet resultSet = null;
	
	/*Method to get the policy detais of the particular insured*/
	@Override
	public ArrayList<PolicyDto> getPolicyData(String username) {
		ArrayList<PolicyDto> policy_list = new ArrayList<PolicyDto>();
		connection = JdbcUtility.getConnection();
		PolicyDto policyDto = null;
		try {
			statement = connection.prepareStatement(POLICY_INFO_USERNAME);
			statement.setString(1, username);
			resultSet = statement.executeQuery();
			
			while(resultSet.next()) {
				policyDto = new PolicyDto();
				policyDto.setPolicyNumber(resultSet.getInt(1));
				policyDto.setPolicyPremium(resultSet.getDouble(2));
				policyDto.setAccountNumber(resultSet.getInt(3));
				policyDto.setStatus(resultSet.getString(4));
				policy_list.add(policyDto);
			}
			
		} catch (SQLException e) {
                logger.error("[Inside InsuredDAO Page] Could'nt connect to database , PolicyList can't be fetched", e);			
		}
		return policy_list;
	}
	
	
	/*Method to get the policy name for the given policy number*/
	@Override
	public String getPolicyName(Integer policyNum) {
		String policyName = null;
		try {
			statement = connection.prepareStatement(GET_POLICY_NAME);
			statement.setInt(1, policyNum);
			resultSet = statement.executeQuery();
			while(resultSet.next()) {
				policyName = resultSet.getString(1);
			}
		} catch (SQLException e) {
			logger.error("Database connectivity error occured while trying to fetch PolicyName ", e);
		} 
		return policyName;
	}

}
